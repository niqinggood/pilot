#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：saddle
@File    ：automl.py
@IDE     ：PyCharm
@Author  ：patrick
@Date    ：2022/6/1 23:00
'''

from autogluon.tabular import TabularPredictor
import logging
import pandas as pd
class AutogluonWrapper:
    def __init__(self,presets="medium_quality_faster_train",model_type="regression"):#  good_quality
        self.presets    = presets
        self.model_type = model_type
    def fit(self,X,y):
        logging.info('X len [%s],y len[%s]  ',len(X),len(y) )
        X_df = pd.DataFrame( X,columns=[ 'X'+str(i) for i in range( 0, len(X[0]) )  ] )
        y_df = pd.DataFrame(y, columns =['y'])
        self.X_names = list(X_df.columns)
        self.y_names = list(y_df.columns)
        train_df     = pd.concat([X_df,y_df],axis=1)
        self.predictor = TabularPredictor(self.y_names[0],problem_type=self.model_type).fit( train_df,presets=self.presets )
    def predict(self,X):
        X_df = pd.DataFrame(X)
        X_df.columns = self.X_names
        if self.model_type=="regression":
            return list(self.predictor.predict(X_df))
        return "not implemented"

import pandas as pd
from autogluon.tabular import TabularDataset, TabularPredictor
def build_train_autogluon_classifier(train_x,train_y,feature_names,presets='best_quality'):
    df_train = pd.concat([pd.DataFrame(train_x, columns=feature_names), pd.DataFrame(train_y, columns=['label'])], axis=1)
    # df_test = pd.concat([pd.DataFrame(test_x, columns=feature_names), pd.DataFrame(test_y, columns=['label'])], axis=1)
    # df_eval = pd.concat([pd.DataFrame(oot_x, columns=feature_names), pd.DataFrame(oot_y, columns=['label'])], axis=1)
    # X_train = pd.concat([df_train, df_test])
    # X_train.reset_index(drop=True, inplace=True)

    from autogluon.tabular import TabularDataset, TabularPredictor
    predictor = TabularPredictor( label='label', problem_type='binary', eval_metric='roc_auc').fit( df_train, presets=presets )

    # predictor = TabularPredictor.load("AutogluonModels/ag-20221025_040314/")
    # train_y_pred = predictor.predict_proba( df_train.drop(columns=['label']) );
    # train_y_pred = train_y_pred[1]
    # test_y_pred = predictor.predict_proba(df_test.drop(columns=['label']));
    # test_y_pred = test_y_pred[1]
    # oot_test_y_pre1 = predictor.predict_proba(df_eval.drop(columns=['label']));
    # oot_test_y_pre1 = oot_test_y_pre1[1]
    return predictor