#!/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：saddle 
@File    ：automl.py
@IDE     ：PyCharm 
@Author  ：patrick
@Date    ：2023/6/1 23:00 
'''
import pandas as pd
from autogluon.tabular import TabularDataset, TabularPredictor
def build_train_autogluon_classifier(train_x,train_y,feature_names,presets='best_quality'):
    df_train = pd.concat([pd.DataFrame(train_x, columns=feature_names), pd.DataFrame(train_y, columns=['label'])], axis=1)
    # df_test = pd.concat([pd.DataFrame(test_x, columns=feature_names), pd.DataFrame(test_y, columns=['label'])], axis=1)
    # df_eval = pd.concat([pd.DataFrame(oot_x, columns=feature_names), pd.DataFrame(oot_y, columns=['label'])], axis=1)
    # X_train = pd.concat([df_train, df_test])
    # X_train.reset_index(drop=True, inplace=True)

    from autogluon.tabular import TabularDataset, TabularPredictor
    predictor = TabularPredictor( label='label', problem_type='binary', eval_metric='roc_auc').fit( df_train, presets=presets )

    # predictor = TabularPredictor.load("AutogluonModels/ag-20221025_040314/")
    # train_y_pred = predictor.predict_proba( df_train.drop(columns=['label']) );
    # train_y_pred = train_y_pred[1]
    # test_y_pred = predictor.predict_proba(df_test.drop(columns=['label']));
    # test_y_pred = test_y_pred[1]
    # oot_test_y_pre1 = predictor.predict_proba(df_eval.drop(columns=['label']));
    # oot_test_y_pre1 = oot_test_y_pre1[1]
    return predictor




if __name__ == '__main__':
    exit()
    
  
  