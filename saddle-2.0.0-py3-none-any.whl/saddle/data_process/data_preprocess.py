# descrirption :
# category_continue_separation
#
import logging
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from category_encoders import OrdinalEncoder, OneHotEncoder
def category_continue_separation(data_df, feature_names):
    ##区分出离散变量与连续变量, 首先要剔除掉target\ label特征;
    #输入是dataframe和 feature_lists
    categorical_var = []
    numerical_var = []
    if 'target' in feature_names :
        feature_names.remove('target')
    if 'label' in feature_names :
        feature_names.remove( 'label' )
    ##先判断类型，如果是int或float就直接作为连续变量 select_dtypes
    numerical_var   = list( data_df[feature_names].select_dtypes(include=['int', 'float', 'int32', 'float32', 'int64', 'float64']).columns.values)
    categorical_var = [x for x in feature_names if x not in numerical_var]
    return categorical_var, numerical_var

def contiues_tranfer_to_category(data_train,data_test,numerical_var,categorical_var,limit_num=10):
    for s in set(numerical_var):
        print('变量' + s + '可能取值' + str(len(data_train[s].unique())))
        if len(data_train[s].unique()) <= limit_num:
            categorical_var.append(s)
            numerical_var.remove(s)
            ##对数值少于一定值的数值变量转为离散特征变量，同时将后加的数值变量转为字符串
            #handle both train and test
            index_1 = data_train[s].isnull()
            if sum(index_1) > 0:
                data_train.loc[~index_1, s] = data_train.loc[~index_1, s].astype('str')
            else:
                data_train[s] = data_train[s].astype('str')
            index_2 = data_test[s].isnull()
            if sum(index_2) > 0:
                data_test.loc[~index_2, s] = data_test.loc[~index_2, s].astype('str')
            else:
                data_test[s] = data_test[s].astype('str')
    return data_train,data_test,numerical_var,categorical_var

#
def get_disc_bin(df, numerical_var,categorical_var ):
    dict_cont_bin = {}  #dict_cont_bin 是每个变量i,后面对应的分箱
    for i in numerical_var:
        print('numerical_var:',i)
        dict_cont_bin[i], gain_value_save_train1, gain_rate_save1 = varbin_meth.cont_var_bin(df[i], df.target, method=2, mmin=3, mmax=12,
                                                                                     bin_rate=0.01, stop_limit=0.05, bin_min_num=20)
    ###离散变量分箱
    dict_disc_bin = {} ; del_key = []
    for i in categorical_var:
        print('categorical_var:', i)
        dict_disc_bin[i], gain_value_save2, gain_rate_save2, del_key_1 = varbin_meth.disc_var_bin(df[i], df.target, method=2, mmin=3,
                                                                                                mmax=8, stop_limit=0.05, bin_min_num=20)
        if len( del_key_1 ) > 0:
            del_key.extend(del_key_1)
            ###删除分箱数只有1个的变量
    return  dict_cont_bin, dict_disc_bin,del_key,gain_value_save_train1, gain_rate_save1,gain_value_save2, gain_rate_save2


# from . import variable_bin_methods  as varbin_meth
# import variable_bin_methods as varbin_meth
def cont_disc_bin_merge( df, dict_cont_bin,dict_disc_bin ):
    ##训练数据分箱，连续变量分箱映射
    df_cont_bin     = pd.DataFrame()
    for i in dict_cont_bin.keys():
        print(i)
        df_cont_bin = pd.concat([df_cont_bin, varbin_meth.cont_var_bin_map(df[i], dict_cont_bin[i])], axis=1)
    ##离散变量分箱映射
    df_disc_bin     = pd.DataFrame()
    for i in dict_disc_bin.keys():
        print(i)
        df_disc_bin = pd.concat([df_disc_bin, varbin_meth. disc_var_bin_map(df[i], dict_disc_bin[i])], axis=1)

    if 'target' in df.columns:
        df_disc_bin['target'] = df.target
    data_bin = pd.concat([df_cont_bin, df_disc_bin], axis=1)

    return  df_cont_bin,df_disc_bin,data_bin

import datetime
def date_str(delat, fmt="%Y-%m-%d", origin_date=datetime.date.today()):
    oneday = datetime.datetime.now().strftime('%Y-%m-%d')
    date = origin_date + datetime.timedelta(delat)
    return date.strftime(fmt)

def sigmod(X):
    return 1.0 / (1 + np.exp(-X))
def Z_ScoreNormalization(x, mu, sigma):
    x = (x - mu) / sigma;
    return x
def als_recommend():
    return
def describe(df):
    df.status_account.unique()
    df.describe()
    #df.drop_duplicates(subset=['order_id'], keep='first', inplace=True)
    #数据清理前期好像用ipynb

    return

def data_clear(df):
    df.status_account.unique()
    return

import pandas as pd
def get_dumies(df,one_hot_feature):
    dummies_df = pd.get_dummies(df, columns=one_hot_feature).fillna(0)
    return dummies_df


from sklearn.preprocessing import StandardScaler
def scaler(data_train,data_test,var_all):
    ####变量归一化,进一步完善
    scaler              = StandardScaler().fit( data_train[var_all])
    data_train[var_all] = scaler.transform( data_train[var_all])
    data_test[var_all]  = scaler.transform( data_test[var_all] )
    return  data_train,data_test



def num_to_ca( data_train,s ):
    index_1 = data_train[s].isnull()
    if sum(index_1) != 0:
        data_train.loc[~index_1, s] = data_train.loc[~index_1, s].astype('str')
    else:
        data_train[s]               = data_train[s].astype('str')
    return data_train

import os
from sklearn.model_selection import train_test_split
def tmpdata_reads(data_path, file_name):
    df = pd.read_csv(os.path.join(data_path, file_name), delim_whitespace=True, header=None)
    ##变量重命名
    columns = ['status_account', 'duration', 'credit_history', 'purpose', 'amount',
               'svaing_account', 'present_emp', 'income_rate', 'personal_status',
               'other_debtors', 'residence_info', 'property', 'age',
               'inst_plans', 'housing', 'num_credits',
               'job', 'dependents', 'telephone', 'foreign_worker', 'target']
    df.columns = columns
    ##将标签变量由状态1,2转为0,1;0表示好用户，1表示坏用户
    df.target = df.target - 1
    ##数据分为data_train和 data_test两部分，训练集用于得到编码函数，验证集用已知的编码规则对验证集编码
    data_train, data_test = train_test_split(df, test_size=0.2, random_state=0, stratify=df.target)
    return data_train, data_test


import logging
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from category_encoders import OrdinalEncoder, OneHotEncoder

def str_to_list(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, str):
        return obj.split(',')

def process_outliers(df, col_proc_dict, if_train, stats_dict=None):
    if stats_dict is None or if_train:
        stats_dict = {}  # 用于保存均值和方差

    for key in col_proc_dict:
        logging.info('begin col_proc_dict key[%s]' % key)
        if 'outlier' in col_proc_dict[key] and key in df.columns:
            # 将列转换为 float 类型
            df[key] = df[key].astype(float)

            # 获取 outlier 配置
            outlier_config = col_proc_dict[key]['outlier']
            logging.info('begin outlier_config key[%s]' % outlier_config)
            # 解析配置：{倍数}std_{处理方式}
            try:
                z_score = float(outlier_config.split('std_')[0])  # 提取倍数
                method = outlier_config.split('std_')[1]  # 提取处理方式
            except (IndexError, ValueError):
                logging.error(f"Invalid outlier config for key[{key}]: {outlier_config}")
                continue

            # 计算均值和标准差（忽略 NaN）
            non_nan_values = df[key].dropna()
            tmp_mean = np.mean(non_nan_values)
            tmp_std = np.std(non_nan_values)

            # 保存均值和方差（如果是 clip 处理）
            if method == 'clip':
                stats_dict[key] = {'mean': tmp_mean, 'std': tmp_std}
            # 推理时使用保存的均值和方差
            if not if_train and method == 'clip' and key in stats_dict:
                tmp_mean = stats_dict[key]['mean']
                tmp_std = stats_dict[key]['std']

            # 计算上下界
            lower_bound = tmp_mean - z_score * tmp_std
            upper_bound = tmp_mean + z_score * tmp_std

            logging.info("key[%s] if_train[%s] tmp_mean[%s] tmp_std[%s] zscore[%s] method[%s] lower_bound:[%s] upper_bound[%s]",
                         key, if_train,tmp_mean, tmp_std, z_score,method,lower_bound,upper_bound)

            if method == 'clip':
                # 截尾处理：对非空、非 NaN 的值进行截断
                logging.info("process clip")
                df.loc[df[key].notna(), key] = df.loc[df[key].notna(), key].clip(lower=lower_bound, upper=upper_bound)#.apply( lambda x: lower_bound  if x <=lower_bound else x).apply(lambda x: upper_bound if x>=upper_bound else x) #
            elif method == 'trainRemove' and if_train:
                logging.info("train outlier remove")
                # 训练去除：仅在训练时对非空、非 NaN 的值进行移除
                logging.info("train outlier remove before len %s", len(df))
                df = df[~((df[key].notna()) & ((df[key] < lower_bound) | (df[key] > upper_bound)))]
                logging.info("train outlier remove after len %s", len(df))
            elif method == 'allRemove':
                logging.info("all outlier remove before len %s",len(df))
                # 全去除：无论训练还是推理，都对非空、非 NaN 的值进行移除
                df = df[~((df[key].notna()) & ((df[key] < lower_bound) | (df[key] > upper_bound)))]
                logging.info("all outlier remove after len %s", len(df))
            else:
                logging.info('unknow method %s',method)
            logging.info('finish process outlier for key[%s]' % key)
            logging.info('finish col_proc_dict key[%s]' % key)
    return df, stats_dict

def data_process(df, keys, xcols, ycol, params, if_train=True, preprocess_dict={}, data_type="train", use_mlflow=None,type_dict={}):
    logging.info('begin data_process,data_type[%s]' , data_type)
    logging.info('preprocess_dict[%s]', preprocess_dict)
    if len(df) < 100: logging.info(f"input df len:%s", len(df))

    for k in type_dict:
        if k in df:
            if type_dict[k] in ['float', 'no']:
                df[k] = df[k].astype(float)
            if type_dict[k] in ['scalar']:
                df[k] = df[k].astype(str)

    col_proc_dict = params.preprocess_json if isinstance(params.preprocess_json, dict) else json.loads( params.preprocess_json )
    outlier_dict   = preprocess_dict.setdefault('outlier_dict', None)
    df,outlier_dict= process_outliers(df            = df,
                                      col_proc_dict = col_proc_dict,
                                      if_train      = True if data_type in ["train"] or if_train else False,
                                      stats_dict    = outlier_dict )

    if params.batchfill is not None:  # batchfill is list
        for batch_config in params.batchfill:
            fill_col, batch_col, fill_type = batch_config.split('|')  # 使用 | 作为分隔符
            if fill_col not in df: continue
            batch_result = fillna_batch_mean(df[[batch_col, fill_col]], batch_col, [fill_col], fill_type)
            logging.info(f"\n批内填充结果（批次字段: {batch_col}, 填充类型: {fill_type}）：batch_result:{batch_result}")
            for col, values in batch_result.items():
                logging.info(f"{col}: {values}")
                df[col] = values
        logging.info("finish fillna_batch_fill")

    if params.removena_num_cols:
        logging.info("begin removena_num_cols %s", params.removena_num_cols)
        if ycol != None and isinstance(ycol, str):
            tmp_cols = [i for i in str_to_list(params.removena_num_cols) if i != ycol]
        elif ycol != None and isinstance(ycol, list):
            tmp_cols = [i for i in str_to_list(params.removena_num_cols) if i not in ycol]
        else:
            tmp_cols = str_to_list(params.removena_num_cols)
        for i in tmp_cols:
            df = df.dropna(subset=[i])
        logging.info("finish removena_num_cols")

    # fillna group mean # 按组填缺
    if params.groupfill is not None:
        logging.info("")
        group_mean_dict = preprocess_dict.setdefault("groupfill", {})
        for group_config in params.groupfill:
            fill_col, group_col, fill_type = group_config.split('|')  # 使用 | 作为分隔符
            if fill_col not in df: continue
            group_result, group_mean_dict = fillna_group_mean(df, group_col, [fill_col], fill_type, group_mean_dict)
            logging.info(f"\n按组填充（训练集）结果（分组字段: {group_col}, 填充类型: {fill_type}）：")
            for col, values in group_result.items():
                logging.info(f"col:{col}  {col}: {values}")
                df[col] = values
        logging.info("finish fillna_group_fill")

    if params.sample_y_begin != None and params.sample_y_end != None and params.sample_ratio != None and data_type == "train" and isinstance(ycol, str):
        logging.info("begin sample")
        if ycol != None and params.sample_ratio > 0 and params.sample_ratio < 1:
            subdf1 = df[(df[ycol] >= params.sample_y_begin) & (df[ycol] < params.sample_y_end)].sample(frac=params.sample_ratio)
            subdf2 = df[(df[ycol] < params.sample_y_begin) | (df[ycol] > params.sample_y_end)]
            df = subdf1.append(subdf2).sample(frac=1.0)
        elif ycol != None and params.sample_ratio > 0 and params.sample_ratio >= 2:
            subdf1 = df[(df[ycol] >= params.sample_y_begin) & (df[ycol] < params.sample_y_end)]
            for i in range(0, int(params.sample_ratio)):
                df = df.append(subdf1)
            df = df.sample(frac=1.0)
        logging.info("finish sample")

    preprocess_dict.setdefault('onehot_dict', {})


    logging.info("begin parse onehot/orinal/zscore/norm/div_max/log cols")
    processed_cols = set()  ## z-score, standard
    labelencoder_cols = [i for i in str_to_list(params.labelencoder_cols) if
                         i not in processed_cols and i != '' and i in xcols] if params.labelencoder_cols != None else [];
    processed_cols = processed_cols | set(labelencoder_cols)

    onehot_cols = [i for i in str_to_list(params.onehot_cols) if i not in processed_cols and i != '' and i in xcols] if params.onehot_cols != None else [];
    processed_cols = processed_cols | set(onehot_cols)
    ordinal_cols = [i for i in str_to_list(params.ordinal_cols) if  i not in processed_cols and i != '' and i in xcols] if params.ordinal_cols != None else [];
    processed_cols = processed_cols | set(ordinal_cols)
    zscore_cols = [i for i in str_to_list(params.zscore_cols) if i not in processed_cols and i != '' and i in xcols] if params.zscore_cols != None else [];
    processed_cols = processed_cols | set(zscore_cols)
    norm_cols = [i for i in str_to_list(params.norm_cols) if  i not in processed_cols and i != '' and i in xcols] if params.norm_cols != None else [];
    processed_cols = processed_cols | set(norm_cols)
    div_max_cols = [i for i in str_to_list(params.divmax_cols) if i not in processed_cols and i != '' and i in xcols] if params.divmax_cols != None else [];
    processed_cols = processed_cols | set(div_max_cols)
    log_cols = [i for i in str_to_list(params.log_cols) if i not in processed_cols and i != '' and i in xcols] if params.log_cols != None else [];
    processed_cols = processed_cols | set(log_cols)
    logging.info("finish parse onehot/orinal/zscore/norm/div_max/log cols")

    # scalar column.

    Labelencoder_dict = preprocess_dict.setdefault('Labelencoder_dict', {})
    onehot_dict, ordinal_dict, zscore_dict, norm_dict, divmax_dict, log_dict = (preprocess_dict.setdefault('onehot_dict',{}  ),
                                                                                preprocess_dict.setdefault('ordinal_dict', {}),
                                                                                preprocess_dict.setdefault('zscore_dict', {} ),
                                                                                preprocess_dict.setdefault('norm_dict',{}    ),
                                                                                preprocess_dict.setdefault('divmax_dict', {} ),
                                                                                preprocess_dict.setdefault('log_dict', {})   )

    if len(labelencoder_cols) != 0:
        logging.info('begin process labelencoder_cols %s', labelencoder_cols)
        for k in labelencoder_cols:
            if if_train:
                label_encoder = LabelEncoder()
                df[k] = label_encoder.fit_transform(df[k])
                Labelencoder_dict.setdefault(k, label_encoder)
            else:
                logging.info('Labelencoder_dict keys:%s', Labelencoder_dict.keys())
                label_encoder = Labelencoder_dict[k]
                df[k] = label_encoder.transform(df[k])
                df[k] = df[k].map(lambda x: x if x in label_encoder.classes_ else -1)
            logging.info('encoder:%s', k)
        logging.info('finish process labelencoder %s', onehot_cols)

    if len(onehot_cols) != 0:
        logging.info('begin process onehot_cols %s', onehot_cols)
        key = '__'.join(onehot_cols)
        if if_train:
            encoder = OneHotEncoder(cols=onehot_cols).fit(df[onehot_cols])
            onehot_dict.setdefault(key, encoder)

        encoder = onehot_dict[key]
        trans_encoder = encoder.transform(df[onehot_cols]).astype(int)
        logging.info('onehot new add xcols:%s', onehot_dict.setdefault('new_add_xcols', list(trans_encoder.columns)))
        logging.info('onehot del xcols:', onehot_dict.setdefault('new_del_xcols', onehot_cols))
        df = pd.concat([df, trans_encoder], axis=1)
        logging.info('encoder:', encoder)
        df.drop(onehot_cols, axis=1, inplace=True)
        logging.info('finish process onehot_cols %s', onehot_cols)

    if len(ordinal_cols) != 0:
        logging.info('begin process ordinal_cols %s', ordinal_cols)
        key = '_'.join(ordinal_cols)

        if if_train:
            encoder = OrdinalEncoder(cols=ordinal_cols, handle_missing='ignore').fit(df[ordinal_cols])
            ordinal_dict.setdefault(key, encoder)
        encoder = ordinal_dict[key]
        trans_encoder = encoder.transform(df[ordinal_cols]).astype(int)  # ordinal_dic
        df[ordinal_cols] = trans_encoder[ordinal_cols]
        logging.info('finish process ordinal_cols %s', ordinal_cols)

    if len(zscore_cols) != 0:
        logging.info('begin process zscore_cols %s', zscore_cols)
        for k in zscore_cols:
            if if_train == True:
                mean_ = df[k].mean()
                std_ = df[k].std()
                mean_ = zscore_dict.setdefault(k + '_mean', mean_)
                std_ = zscore_dict.setdefault(k + '_std', std_)
                df[k] = (df[k] - mean_) / std_
            if params.zscore_cut != None and params.zscore_cut > 0:
                df[k] = df[k].apply(lambda x: params.zscore_cut * np.sign(x) if abs(x) >= params.zscore_cut else x)
        logging.info('finish  process zscore_cols %s', zscore_cols)

    if len(norm_cols) != 0:
        logging.info('begin process norm_cols %s', norm_cols)
        key = '_'.join(norm_cols)
        if if_train:
            encoder = MinMaxScaler().fit(df[norm_cols])
            norm_dict.setdefault(key, encoder)

        trans_encoder = norm_dict[key].transform(df[norm_cols])
        df[norm_cols] = trans_encoder  # [ norm_cols ]
        logging.info('finish process norm_cols %s', norm_cols)

    if len(div_max_cols) != 0:
        logging.info('begin process div_max_cols %s', div_max_cols)
        for k in div_max_cols:
            if if_train == True:
                max_ = max(df[k])
                divmax_dict.setdefault(k, max_)
            max_ = divmax_dict.setdefault(k, 0)
            if max_ != 0:
                df[k] = df[k].apply(lambda x: x / max_)
        logging.info('finish process div_max_cols %s', div_max_cols)
    if len(log_cols) != 0:
        for k in log_cols:
            df[k] = df[k].apply(lambda x: np.log(x))
        logging.info('finish process %s', div_max_cols)

    logging.info('output df columns:%s', list(df.columns))
    logging.info(f"output df.head:\n{df.head()}")
    logging.info('finish data_process,data_type[%s]' % data_type)

    if if_train or data_type in ['train']:
        preprocess_dict['outlier_dict'] = outlier_dict
        preprocess_dict['zscore_dict']  = zscore_dict
        preprocess_dict['norm_dict']    = norm_dict
        preprocess_dict['divmax_dict']  = divmax_dict
        preprocess_dict['onehot_dict']  = onehot_dict
        preprocess_dict['ordinal_dict'] = ordinal_dict
        return df, preprocess_dict
    else:
        return df



def fillna_batch_mean(df, batch_col, fill_cols, fill_type='num'):
    """
    批内填充：按某个批次字段，在同一批次内进行填充
    :param df: DataFrame，需要填充的数据（可以是精简的 DataFrame）
    :param batch_col: str，批次字段（如 'LOT_ID'）
    :param fill_cols: list，需要填充的字段列表
    :param fill_type: str，填充类型（'num' 表示数值类，'scalar' 表示标量类）
    :return: dict，填充后的列结果（Series 的值）
    """
    logging.info(f"begin fillna_batch_mean with batch_col: {batch_col},fill_cols:{fill_cols}, fill_type: {fill_type}")

    # 确保填充字段为数值类型（如果是数值类）
    if fill_type == 'num':
        df[fill_cols] = df[fill_cols].astype(float)

    # 按批次字段计算批内均值或众数
    if fill_type == 'num':
        batch_fill_df = df[[batch_col] + fill_cols].groupby([batch_col]).transform(lambda x: x.fillna(x.mean()))
    elif fill_type == 'scalar':
        batch_fill_df = df[[batch_col] + fill_cols].groupby([batch_col]).transform(
            lambda x: x.fillna(x.mode(dropna=True).iloc[0] if not x.mode(dropna=True).empty else x.dropna().iloc[0]))
    else:
        logging.error(f' {fill_type} unknown type')
        return {}

    # 提取填充后的列结果（Series 的值）
    result = {col: batch_fill_df[col].values for col in fill_cols}
    logging.info(f"finish fillna_batch_mean with batch_col: {batch_col},fill_cols:{fill_cols}, fill_type: {fill_type}")
    return result

def fillna_group_mean(df, group_col, fill_cols, fill_type='num', group_mean_dict=None):
    """
    按组填充：按某个分组字段统计某列不为 null 的均值或众数，用于填充同组内为 null 的值
    :param df: DataFrame，需要填充的数据（可以是精简的 DataFrame）
    :param group_col: str，分组字段（如 'CHAMBER_ID'）
    :param fill_cols: list，需要填充的字段列表
    :param fill_type: str，填充类型（'num' 表示数值类，'scalar' 表示标量类）
    :param group_mean_dict: dict，训练集的分组均值字典（用于测试集填充）
    :return: dict，填充后的列结果（Series 的值）
    """
    logging.info(f"begin fillna_group_mean with group_col: {group_col}, fill_type: {fill_type}")

    # 确保填充字段为数值类型（如果是数值类）
    if fill_type == 'num':
        df[fill_cols] = df[fill_cols].astype(float)

    # 如果是训练集，计算并保存分组均值或众数
        # 如果是训练集，计算并保存分组均值或众数
    if group_mean_dict is None or not group_mean_dict.keys():  # 检查是否为空
        group_mean_dict = {}
        for col in fill_cols:
            if fill_type == 'num':
                group_mean_dict[col] = df[[group_col, col]].groupby([group_col]).mean().reset_index()
            elif fill_type == 'scalar':
                group_mean_dict[col] = df[[group_col, col]].groupby([group_col]).apply(
                    lambda x: x[col].mode().iloc[0]).reset_index()
                group_mean_dict[col].columns = [group_col, col]
            else:
                logging.error(f"{col} unknown type")

    # 如果是测试集，使用训练集的分组均值或众数进行填充
    result = {}
    for col in fill_cols:
        # 合并测试集和训练集的分组均值或众数
        df = pd.merge(df, group_mean_dict[col], on=[group_col], how='left', suffixes=('', '_mean'))
        # 使用分组均值或众数填充缺失值
        df[col] = df[col].fillna(df[f"{col}_mean"])
        # 提取填充后的列结果（Series 的值）
        result[col] = df[col].values
        # 删除均值列
        df = df.drop(columns=[f"{col}_mean"])

    logging.info(f"finish fillna_group_mean with group_col: {group_col}, fill_type: {fill_type}")
    return result, group_mean_dict

def str_to_list(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, str):
        return obj.split(',')

def process_outliers(df, col_proc_dict, if_train, stats_dict=None):
    if stats_dict is None or if_train:
        stats_dict = {}  # 用于保存均值和方差

    for key in col_proc_dict:
        logging.info('begin col_proc_dict key[%s]' % key)
        if 'outlier' in col_proc_dict[key] and key in df.columns:
            # 将列转换为 float 类型
            df[key] = df[key].astype(float)

            # 获取 outlier 配置
            outlier_config = col_proc_dict[key]['outlier']
            logging.info('begin outlier_config key[%s]' % outlier_config)
            # 解析配置：{倍数}std_{处理方式}
            try:
                z_score = float(outlier_config.split('std_')[0])  # 提取倍数
                method = outlier_config.split('std_')[1]  # 提取处理方式
            except (IndexError, ValueError):
                logging.error(f"Invalid outlier config for key[{key}]: {outlier_config}")
                continue

            # 计算均值和标准差（忽略 NaN）
            non_nan_values = df[key].dropna()
            tmp_mean = np.mean(non_nan_values)
            tmp_std = np.std(non_nan_values)

            # 保存均值和方差（如果是 clip 处理）
            if method == 'clip':
                stats_dict[key] = {'mean': tmp_mean, 'std': tmp_std}
            # 推理时使用保存的均值和方差
            if not if_train and method == 'clip' and key in stats_dict:
                tmp_mean = stats_dict[key]['mean']
                tmp_std = stats_dict[key]['std']

            # 计算上下界
            lower_bound = tmp_mean - z_score * tmp_std
            upper_bound = tmp_mean + z_score * tmp_std

            logging.info("key[%s] if_train[%s] tmp_mean[%s] tmp_std[%s] zscore[%s] method[%s] lower_bound:[%s] upper_bound[%s]",
                         key, if_train,tmp_mean, tmp_std, z_score,method,lower_bound,upper_bound)

            if method == 'clip':
                # 截尾处理：对非空、非 NaN 的值进行截断
                logging.info("process clip")
                df.loc[df[key].notna(), key] = df.loc[df[key].notna(), key].clip(lower=lower_bound, upper=upper_bound)#.apply( lambda x: lower_bound  if x <=lower_bound else x).apply(lambda x: upper_bound if x>=upper_bound else x) #
            elif method == 'trainRemove' and if_train:
                logging.info("train outlier remove")
                # 训练去除：仅在训练时对非空、非 NaN 的值进行移除
                logging.info("train outlier remove before len %s", len(df))
                df = df[~((df[key].notna()) & ((df[key] < lower_bound) | (df[key] > upper_bound)))]
                logging.info("train outlier remove after len %s", len(df))
            elif method == 'allRemove':
                logging.info("all outlier remove before len %s",len(df))
                # 全去除：无论训练还是推理，都对非空、非 NaN 的值进行移除
                df = df[~((df[key].notna()) & ((df[key] < lower_bound) | (df[key] > upper_bound)))]
                logging.info("all outlier remove after len %s", len(df))
            else:
                logging.info('unknow method %s',method)
            logging.info('finish process outlier for key[%s]' % key)
            logging.info('finish col_proc_dict key[%s]' % key)
    return df, stats_dict

def data_process_byparams(df, keys, xcols, ycol, params, if_train=True, preprocess_dict={}, data_type="train", use_mlflow=None,type_dict={}):
    logging.info('begin data_process,data_type[%s]' , data_type)
    logging.info('preprocess_dict[%s]', preprocess_dict)
    if len(df) < 100: logging.info(f"input df len:%s", len(df))

    for k in type_dict:
        if k in df:
            if type_dict[k] in ['float', 'no']:
                df[k] = df[k].astype(float)
            if type_dict[k] in ['scalar']:
                df[k] = df[k].astype(str)

    col_proc_dict = params.preprocess_json if isinstance(params.preprocess_json, dict) else json.loads( params.preprocess_json )
    outlier_dict   = preprocess_dict.setdefault('outlier_dict', None)
    df,outlier_dict= process_outliers(df            = df,
                                      col_proc_dict = col_proc_dict,
                                      if_train      = True if data_type in ["train"] or if_train else False,
                                      stats_dict    = outlier_dict )

    if params.batchfill is not None:  # batchfill is list
        for batch_config in params.batchfill:
            fill_col, batch_col, fill_type = batch_config.split('|')  # 使用 | 作为分隔符
            if fill_col not in df: continue
            batch_result = fillna_batch_mean(df[[batch_col, fill_col]], batch_col, [fill_col], fill_type)
            logging.info(f"\n批内填充结果（批次字段: {batch_col}, 填充类型: {fill_type}）：batch_result:{batch_result}")
            for col, values in batch_result.items():
                logging.info(f"{col}: {values}")
                df[col] = values
        logging.info("finish fillna_batch_fill")

    if params.removena_num_cols:
        logging.info("begin removena_num_cols %s", params.removena_num_cols)
        if ycol != None and isinstance(ycol, str):
            tmp_cols = [i for i in str_to_list(params.removena_num_cols) if i != ycol]
        elif ycol != None and isinstance(ycol, list):
            tmp_cols = [i for i in str_to_list(params.removena_num_cols) if i not in ycol]
        else:
            tmp_cols = str_to_list(params.removena_num_cols)
        for i in tmp_cols:
            df = df.dropna(subset=[i])
        logging.info("finish removena_num_cols")

    # fillna group mean # 按组填缺
    if params.groupfill is not None:
        logging.info("")
        group_mean_dict = preprocess_dict.setdefault("groupfill", {})
        for group_config in params.groupfill:
            fill_col, group_col, fill_type = group_config.split('|')  # 使用 | 作为分隔符
            if fill_col not in df: continue
            group_result, group_mean_dict = fillna_group_mean(df, group_col, [fill_col], fill_type, group_mean_dict)
            logging.info(f"\n按组填充（训练集）结果（分组字段: {group_col}, 填充类型: {fill_type}）：")
            for col, values in group_result.items():
                logging.info(f"col:{col}  {col}: {values}")
                df[col] = values
        logging.info("finish fillna_group_fill")

    if params.sample_y_begin != None and params.sample_y_end != None and params.sample_ratio != None and data_type == "train" and isinstance(ycol, str):
        logging.info("begin sample")
        if ycol != None and params.sample_ratio > 0 and params.sample_ratio < 1:
            subdf1 = df[(df[ycol] >= params.sample_y_begin) & (df[ycol] < params.sample_y_end)].sample(frac=params.sample_ratio)
            subdf2 = df[(df[ycol] < params.sample_y_begin) | (df[ycol] > params.sample_y_end)]
            df = subdf1.append(subdf2).sample(frac=1.0)
        elif ycol != None and params.sample_ratio > 0 and params.sample_ratio >= 2:
            subdf1 = df[(df[ycol] >= params.sample_y_begin) & (df[ycol] < params.sample_y_end)]
            for i in range(0, int(params.sample_ratio)):
                df = df.append(subdf1)
            df = df.sample(frac=1.0)
        logging.info("finish sample")

    preprocess_dict.setdefault('onehot_dict', {})


    logging.info("begin parse onehot/orinal/zscore/norm/div_max/log cols")
    processed_cols = set()  ## z-score, standard
    labelencoder_cols = [i for i in str_to_list(params.labelencoder_cols) if
                         i not in processed_cols and i != '' and i in xcols] if params.labelencoder_cols != None else [];
    processed_cols = processed_cols | set(labelencoder_cols)

    onehot_cols = [i for i in str_to_list(params.onehot_cols) if i not in processed_cols and i != '' and i in xcols] if params.onehot_cols != None else [];
    processed_cols = processed_cols | set(onehot_cols)
    ordinal_cols = [i for i in str_to_list(params.ordinal_cols) if  i not in processed_cols and i != '' and i in xcols] if params.ordinal_cols != None else [];
    processed_cols = processed_cols | set(ordinal_cols)
    zscore_cols = [i for i in str_to_list(params.zscore_cols) if i not in processed_cols and i != '' and i in xcols] if params.zscore_cols != None else [];
    processed_cols = processed_cols | set(zscore_cols)
    norm_cols = [i for i in str_to_list(params.norm_cols) if  i not in processed_cols and i != '' and i in xcols] if params.norm_cols != None else [];
    processed_cols = processed_cols | set(norm_cols)
    div_max_cols = [i for i in str_to_list(params.divmax_cols) if i not in processed_cols and i != '' and i in xcols] if params.divmax_cols != None else [];
    processed_cols = processed_cols | set(div_max_cols)
    log_cols = [i for i in str_to_list(params.log_cols) if i not in processed_cols and i != '' and i in xcols] if params.log_cols != None else [];
    processed_cols = processed_cols | set(log_cols)
    logging.info("finish parse onehot/orinal/zscore/norm/div_max/log cols")

    # scalar column.

    Labelencoder_dict = preprocess_dict.setdefault('Labelencoder_dict', {})
    onehot_dict, ordinal_dict, zscore_dict, norm_dict, divmax_dict, log_dict = (preprocess_dict.setdefault('onehot_dict',{}  ),
                                                                                preprocess_dict.setdefault('ordinal_dict', {}),
                                                                                preprocess_dict.setdefault('zscore_dict', {} ),
                                                                                preprocess_dict.setdefault('norm_dict',{}    ),
                                                                                preprocess_dict.setdefault('divmax_dict', {} ),
                                                                                preprocess_dict.setdefault('log_dict', {})   )

    if len(labelencoder_cols) != 0:
        logging.info('begin process labelencoder_cols %s', labelencoder_cols)
        for k in labelencoder_cols:
            if if_train:
                label_encoder = LabelEncoder()
                df[k] = label_encoder.fit_transform(df[k])
                Labelencoder_dict.setdefault(k, label_encoder)
            else:
                logging.info('Labelencoder_dict keys:%s', Labelencoder_dict.keys())
                label_encoder = Labelencoder_dict[k]
                df[k] = label_encoder.transform(df[k])
                df[k] = df[k].map(lambda x: x if x in label_encoder.classes_ else -1)
            logging.info('encoder:%s', k)
        logging.info('finish process labelencoder %s', onehot_cols)

    if len(onehot_cols) != 0:
        logging.info('begin process onehot_cols %s', onehot_cols)
        key = '__'.join(onehot_cols)
        if if_train:
            encoder = OneHotEncoder(cols=onehot_cols).fit(df[onehot_cols])
            onehot_dict.setdefault(key, encoder)

        encoder = onehot_dict[key]
        trans_encoder = encoder.transform(df[onehot_cols]).astype(int)
        logging.info('onehot new add xcols:%s', onehot_dict.setdefault('new_add_xcols', list(trans_encoder.columns)))
        logging.info('onehot del xcols:', onehot_dict.setdefault('new_del_xcols', onehot_cols))
        df = pd.concat([df, trans_encoder], axis=1)
        logging.info('encoder:', encoder)
        df.drop(onehot_cols, axis=1, inplace=True)
        logging.info('finish process onehot_cols %s', onehot_cols)

    if len(ordinal_cols) != 0:
        logging.info('begin process ordinal_cols %s', ordinal_cols)
        key = '_'.join(ordinal_cols)

        if if_train:
            encoder = OrdinalEncoder(cols=ordinal_cols, handle_missing='ignore').fit(df[ordinal_cols])
            ordinal_dict.setdefault(key, encoder)
        encoder = ordinal_dict[key]
        trans_encoder = encoder.transform(df[ordinal_cols]).astype(int)  # ordinal_dic
        df[ordinal_cols] = trans_encoder[ordinal_cols]
        logging.info('finish process ordinal_cols %s', ordinal_cols)

    if len(zscore_cols) != 0:
        logging.info('begin process zscore_cols %s', zscore_cols)
        for k in zscore_cols:
            if if_train == True:
                mean_ = df[k].mean()
                std_ = df[k].std()
                mean_ = zscore_dict.setdefault(k + '_mean', mean_)
                std_ = zscore_dict.setdefault(k + '_std', std_)
                df[k] = (df[k] - mean_) / std_
            if params.zscore_cut != None and params.zscore_cut > 0:
                df[k] = df[k].apply(lambda x: params.zscore_cut * np.sign(x) if abs(x) >= params.zscore_cut else x)
        logging.info('finish  process zscore_cols %s', zscore_cols)

    if len(norm_cols) != 0:
        logging.info('begin process norm_cols %s', norm_cols)
        key = '_'.join(norm_cols)
        if if_train:
            encoder = MinMaxScaler().fit(df[norm_cols])
            norm_dict.setdefault(key, encoder)

        trans_encoder = norm_dict[key].transform(df[norm_cols])
        df[norm_cols] = trans_encoder  # [ norm_cols ]
        logging.info('finish process norm_cols %s', norm_cols)

    if len(div_max_cols) != 0:
        logging.info('begin process div_max_cols %s', div_max_cols)
        for k in div_max_cols:
            if if_train == True:
                max_ = max(df[k])
                divmax_dict.setdefault(k, max_)
            max_ = divmax_dict.setdefault(k, 0)
            if max_ != 0:
                df[k] = df[k].apply(lambda x: x / max_)
        logging.info('finish process div_max_cols %s', div_max_cols)
    if len(log_cols) != 0:
        for k in log_cols:
            df[k] = df[k].apply(lambda x: np.log(x))
        logging.info('finish process %s', div_max_cols)

    logging.info('output df columns:%s', list(df.columns))
    logging.info(f"output df.head:\n{df.head()}")
    logging.info('finish data_process,data_type[%s]' % data_type)

    if if_train or data_type in ['train']:
        preprocess_dict['outlier_dict'] = outlier_dict
        preprocess_dict['zscore_dict']  = zscore_dict
        preprocess_dict['norm_dict']    = norm_dict
        preprocess_dict['divmax_dict']  = divmax_dict
        preprocess_dict['onehot_dict']  = onehot_dict
        preprocess_dict['ordinal_dict'] = ordinal_dict
        return df, preprocess_dict
    else:
        return df


def fillna_batch_mean(df, batch_col, fill_cols, fill_type='num'):
    """
    批内填充：按某个批次字段，在同一批次内进行填充
    :param df: DataFrame，需要填充的数据（可以是精简的 DataFrame）
    :param batch_col: str，批次字段（如 'LOT_ID'）
    :param fill_cols: list，需要填充的字段列表
    :param fill_type: str，填充类型（'num' 表示数值类，'scalar' 表示标量类）
    :return: dict，填充后的列结果（Series 的值）
    """
    logging.info(f"begin fillna_batch_mean with batch_col: {batch_col},fill_cols:{fill_cols}, fill_type: {fill_type}")

    # 确保填充字段为数值类型（如果是数值类）
    if fill_type == 'num':
        df[fill_cols] = df[fill_cols].astype(float)

    # 按批次字段计算批内均值或众数
    if fill_type == 'num':
        batch_fill_df = df[[batch_col] + fill_cols].groupby([batch_col]).transform(lambda x: x.fillna(x.mean()))
    elif fill_type == 'scalar':
        batch_fill_df = df[[batch_col] + fill_cols].groupby([batch_col]).transform(
            lambda x: x.fillna(x.mode(dropna=True).iloc[0] if not x.mode(dropna=True).empty else x.dropna().iloc[0]))
    else:
        logging.error(f' {fill_type} unknown type')
        return {}

    # 提取填充后的列结果（Series 的值）
    result = {col: batch_fill_df[col].values for col in fill_cols}
    logging.info(f"finish fillna_batch_mean with batch_col: {batch_col},fill_cols:{fill_cols}, fill_type: {fill_type}")
    return result

def fillna_group_mean(df, group_col, fill_cols, fill_type='num', group_mean_dict=None):
    """
    按组填充：按某个分组字段统计某列不为 null 的均值或众数，用于填充同组内为 null 的值
    :param df: DataFrame，需要填充的数据（可以是精简的 DataFrame）
    :param group_col: str，分组字段（如 'CHAMBER_ID'）
    :param fill_cols: list，需要填充的字段列表
    :param fill_type: str，填充类型（'num' 表示数值类，'scalar' 表示标量类）
    :param group_mean_dict: dict，训练集的分组均值字典（用于测试集填充）
    :return: dict，填充后的列结果（Series 的值）
    """
    logging.info(f"begin fillna_group_mean with group_col: {group_col}, fill_type: {fill_type}")

    # 确保填充字段为数值类型（如果是数值类）
    if fill_type == 'num':
        df[fill_cols] = df[fill_cols].astype(float)

    # 如果是训练集，计算并保存分组均值或众数
        # 如果是训练集，计算并保存分组均值或众数
    if group_mean_dict is None or not group_mean_dict.keys():  # 检查是否为空
        group_mean_dict = {}
        for col in fill_cols:
            if fill_type == 'num':
                group_mean_dict[col] = df[[group_col, col]].groupby([group_col]).mean().reset_index()
            elif fill_type == 'scalar':
                group_mean_dict[col] = df[[group_col, col]].groupby([group_col]).apply(
                    lambda x: x[col].mode().iloc[0]).reset_index()
                group_mean_dict[col].columns = [group_col, col]
            else:
                logging.error(f"{col} unknown type")

    # 如果是测试集，使用训练集的分组均值或众数进行填充
    result = {}
    for col in fill_cols:
        # 合并测试集和训练集的分组均值或众数
        df = pd.merge(df, group_mean_dict[col], on=[group_col], how='left', suffixes=('', '_mean'))
        # 使用分组均值或众数填充缺失值
        df[col] = df[col].fillna(df[f"{col}_mean"])
        # 提取填充后的列结果（Series 的值）
        result[col] = df[col].values
        # 删除均值列
        df = df.drop(columns=[f"{col}_mean"])

    logging.info(f"finish fillna_group_mean with group_col: {group_col}, fill_type: {fill_type}")
    return result, group_mean_dict

if __name__ == '__main__':

    print('data_preprocess')