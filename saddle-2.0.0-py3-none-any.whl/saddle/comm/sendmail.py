import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import sys
import inspect
import pandas as pd

# from config import logger
class EmailSender(object):
    def __init__(self,config={"host":"smtp.163.com","user":"",'pass':""}):
        self.mail_host = config['host']
        self.mail_user = config['user']
        self.mail_pass = config.get('pass','')

    def append_file(self,file_path, content, mode='a'):
        """Append content to a file."""
        with open(file_path, mode) as file:
            file.write(content)

    def make_dir(self,path):
        """Create directory if it doesn't exist."""
        import os
        if not os.path.exists(path):
            os.makedirs(path)

    def convert_to_html(self,content_list):
        """Convert markdown-like content to HTML with headers and paragraphs."""
        html_content = ""
        for content in content_list:
            if isinstance(content, str):
                if content.startswith('### '):
                    html_content += f"<h3>{content[4:].strip()}</h3>"
                elif content.startswith('## '):
                    html_content += f"<h2>{content[3:].strip()}</h2>"
                elif content.startswith('# '):
                    html_content += f"<h1>{content[2:].strip()}</h1>"
                else:
                    html_content += f"<p>{content}</p>"
            elif isinstance(content, pd.DataFrame):
                # Convert DataFrame to a clean HTML table
                html_table = content.to_html(index=False, border=0, classes='dataframe', justify='left')
                html_content += html_table
        return html_content

    def _generate_html_content(self,subject, body_content, summary_info=""):
        """Generate HTML content for email body."""
        html_content = f"""
        <html>
        <head>
        <style>
            body {{ font-family: Arial, sans-serif; }}
            h1 {{ color: blue; }}
            h2 {{ color: darkblue; }}
            h3 {{ color: steelblue; }}
            p {{ font-size: 14px; }}
            table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #e6f2ff; }} /* Light blue header for distinction */
            tr:nth-child(even) {{ background-color: #f2f2f2; }}
            tr:hover {{ background-color: #ddd; }}
        </style>
        </head>
        <body>
        <p>{summary_info}</p>
        {body_content}
        </body></html>
        """
        # <h1>{subject}</h1>
        return html_content

    def work(self, to_addr, subject, body_content, is_table=False, att_file_name="", summary_file_name="", author="DA",upper_file="unknown",suffix='@163.com'):
        """Compose and send the email."""
        to_addr_list = to_addr.split(",")
        to_addr = ",".join([f"{addr}"+suffix if "@" not in addr else addr for addr in to_addr_list])

        sum_info = open(summary_file_name, 'r').read() if summary_file_name else ""
        upper_file = inspect.getsourcefile(inspect.currentframe().f_back) if upper_file == "unknown" else upper_file
        msg = MIMEMultipart()
        # Create the email body with HTML content
        msg_content = MIMEText(self._generate_html_content(subject, body_content, sum_info), "html", "utf-8")

        msg["From"]     = self.mail_user
        msg["To"]       = to_addr
        msg["Subject"]  = subject
        msg.attach(     msg_content )

        if att_file_name:
            with open(att_file_name, 'rb') as att_file:
                att = MIMEApplication(att_file.read())
            att.add_header('Content-Disposition', 'attachment', filename=att_file_name.split('/')[-1])
            msg.attach(att)

        c = smtplib.SMTP()
        c.connect(  self.mail_host)
        c.login(    self.mail_user, self.mail_pass)
        c.sendmail( self.mail_user, to_addr.split(","), msg.as_string() )
        c.quit()

    def send_mail(self,to_addr, subject, body_list=[], summary_str='', is_table=True, att_file_name='',email_dir='email_data', tag=''):
        """Send an email with the given content and attachments."""
        import datetime
        import os
        self.make_dir(email_dir)
        today_str = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S')
        body_file = os.path.join(email_dir, f"{tag}body_{today_str}.html")
        sum_file  = os.path.join(email_dir, f"{tag}sum_{today_str}.txt")

        html_body_content = self.convert_to_html( body_list )

        # Write body content to file
        self.append_file(body_file, html_body_content, 'w')
        self.append_file(sum_file, summary_str, 'w')
        self.work(to_addr, subject, html_body_content, is_table=is_table, att_file_name=att_file_name,
             summary_file_name=sum_file, author="DA", upper_file="unknown")
        import logging
        logging.info("send email succ")

if __name__ == '__main__':
    df = pd.DataFrame([list(range(0, 10)), list(range(0, 10)), list(range(0, 10)), list(range(0, 10))],
                      columns=['columns' + str(i) for i in range(10)])
    email_sender = EmailSender( )
    email_sender.send_mail(to_addr='niqinggood@163.com',
              subject='Test Email with Improved Table Style',
              body_list=['# 你好呀', df, '## 你好呢', df,'### hao', 'Some plain text', df],
              summary_str='This is the email summary')