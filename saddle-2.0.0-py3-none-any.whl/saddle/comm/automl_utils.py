import argparse
import logging
import copy
def map_to_localargs(r_c):
    #    preprocess_json  :   { "字段": {  "inout_type"/"data_type":num /scalar/ cat ,
    #                                      "proc"  : minmax/log/zscore  or ordinal/onehot/label/onehot/remove,
    #                                      "fillna": proc_method
    #                                      "batch" : proc_method }

    logging.info('begin map_to_localargs')
    r_c = {k.lower(): v for k, v in r_c.items()}
    logging.info(f"r_c detail:{r_c}")
    if 'preprocess' in r_c:
        r_c['preprocess_json'] = r_c['preprocess']
    new_dict = {}
    if 'preprocess_json' in r_c:
        r_c['zscore_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'procproc' in v and v['proc'] == 'zscore']
        r_c['norm_cols']        = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] in [ 'norm','minmaxscaler'] ]
        r_c['divmax_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] == 'divmax']
        r_c['log_cols']         = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and 'proc' in v and v['proc'] == 'log']
        r_c['ordinal_cols']     = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'ordinal']
        r_c['onehot_cols']      = [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'onehot']
        r_c['labelencoder_cols']= [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') in ['cat','scalar']) and 'proc' in v and v['proc'] == 'label']
        r_c["removena_num_cols"]= [k for k, v in r_c["preprocess_json"].items() if (v.get('data_type') == 'num') and "fillna" in v and v["fillna"] in [ "remove_nan","remove"] ]

    new_dict =  { i:r_c[i] for i in r_c }
    new_dict.setdefault('tuning_json', '');
    new_dict.setdefault('search_algo', 'TPE');
    new_dict.setdefault('train_eda', 'detail');
    new_dict.setdefault('split_key', 'LOT_ID');
    new_dict.setdefault('test_ratio', 0.2);
    new_dict.setdefault('except_sigma_for_num', 5);
    new_dict.setdefault('except_sigma_for_y', 5);
    new_dict.setdefault('reg_metrics', 'MAE');
    new_dict.setdefault('cl_metrics', 'f1-score');
    new_dict.setdefault('model_save_candidates', 'LR,Ridge,Lasso,PLS,Xgboost,LightGBM,Catboost');
    new_dict.setdefault('bin_num', 10)
    new_dict.setdefault('preprocess_json', '')
    new_dict.setdefault("batchfill", None )
    new_dict.setdefault("groupfill", None )
    new_dict.setdefault("sample_y_begin",None)
    if 'keys' in new_dict and (new_dict['keys'] is None or new_dict["keys"] == 'NoneType'):  new_dict['keys'] = []

    args = argparse.Namespace(**new_dict)
    logging.info('finish map_to_localargs:%s',args)
    return args

# if 'mode' in r_c and r_c["mode"].lower() == "tuning":
#     r_c["algo_name"] = r_c["algorithm"][0]["name"] if "name" in r_c["algorithm"][0] else None
#     r_c["search_algo"] = r_c["algorithm"][0]["search_algo"] if "search_algo" in r_c["algorithm"][0] else None
#     r_c['tuning_json'] = r_c["algorithm"][0]
#
#     else:
#         for k in copy.deepcopy(r_c['tuning_json']):
#             if r_c['tuning_json'][k] == "":
#                 r_c['tuning_json'].pop(k, None)
#                 continue
#             r_c['tuning_json'][k] = [eval(i) for i in r_c['tuning_json'][k].split(',')]