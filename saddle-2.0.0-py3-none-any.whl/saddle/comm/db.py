import pandas as pd
from sqlalchemy import text
import sqlalchemy as sa
import logging
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import mysql.connector
import cx_Oracle

def get_oracle_engine(user,password,ip_port,db,mode:str="sid"):
    if mode.lower()=="sid":
        return sa.create_engine("oracle+cx_oracle://%s:%s@%s/%s" %(user,password,ip_port,db),max_overflow=15,pool_recycle=600,pool_size=0 )
    elif mode.lower()=="servicename":
        return sa.create_engine("oracle+cx_oracle://%s:%s@%s/?service_name=%s" %(user,password,ip_port,db),max_overflow=15,pool_recycle=600,pool_size=0 )
    else:
        raise ValueError("Wrong mode, should be either 'sid' or 'servicename'")

def get_mysql_engine(user,passwd,ip_port,db):
    from urllib.parse import quote_plus
    encoded_passwd = quote_plus(passwd)
    #if '@' in passwd : passwd = passwd.replace('@','%40')
    return sa.create_engine("mysql+pymysql://%s:%s@%s/%s?charset=utf8mb4"%(user,encoded_passwd,ip_port,db ),max_overflow=15,pool_recycle=600,pool_size=0  )

from typing import Optional,Callable
def get_sql_df(sql,sa_engine,func: Optional[Callable] = None):
    logging.info('######sql:\n%s',sql)
    df = pd.read_sql(sql,sa_engine)
    if func!=None:
        df = func( df )
    logging.info("######ssampledf:\n%s",df.head(2) )
    return df

def to_sqlin_str(in_list):
    if type(in_list) == str:
        in_list = [in_list]
    ret_str = str( tuple(in_list) ).replace(  ',)',','  )
    return ret_str

def selectDB_oracle(connect,sql,val=() ):
    mycursor = connect.cursor()
    mycursor.excute(sql,val)
    myresult = mycursor.fetchall()
    mycursor.close()
    return myresult