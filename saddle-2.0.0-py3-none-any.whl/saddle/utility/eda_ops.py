import argparse
import pandas as pd
# import pandas_profiling as pp
import ydata_profiling  as pp
import logging
from aiutils.utils import set_logging
set_logging( "log", 'test', mode='dev')
def main():
    parser = argparse.ArgumentParser(description="Generate a pandas profiling report.")
    parser.add_argument("--input_file",type=str,default="train_bin.csv",help="Input file path")
    parser.add_argument("--output", type=str, default="report.html", help="Output file path (defualt:report.html)")

    args    = parser.parse_args()
    df      = pd.read_csv(args.input_file )
    #生成报告
    print("args:",args)
    logging.info(  'begin run ############' )
    profile = pp.ProfileReport(df,title="%s Profiling Report"% args.input_file )
    profile.to_file( output_file=args.output )

if __name__=="__main__":
    main()
  
  