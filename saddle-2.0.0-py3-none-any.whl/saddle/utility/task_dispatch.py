import json
from random import sample

import pandas
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression
from lightgbm import LGBMRegressor
from swift.llm.dataset.dataset.mllm import subset
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
import seaborn as sns
import matplotlib.pyplot as plt
import copy
import numpy as np
import networkx as nx
import logging
import os
import pandas as pd
import traceback
from flask import Flask, request, jsonify


def download_file_from_url(url, save_path):
    """
    从 URL 下载文件并保存到指定路径
    :param url: 文件的 URL 链接
    :param save_path: 保存文件的路径
    """
    import requests
    try:
        # 发送 GET 请求
        response = requests.get(url, stream=True)
        response.raise_for_status()  # 检查请求是否成功

        # 将文件写入本地
        with open(save_path, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        logging.info(f"File downloaded successfully: {save_path}")
    except requests.exceptions.RequestException as e:
        logging.info(f"Error downloading file: {e}")


def load_model(projectName, trainingRecord):
    load_file = os.path.join('projects', projectName,
                             trainingRecord.replace("Result-", '').replace("Result",''),
                             '%s__engine.pkl' % projectName)

    # port       = config_['port']
    # apiUrl     = config_.get('apiUrl','/test')
    ai_agent = joblib.load(load_file)
    return ai_agent


def predict_data_trans( data, labelname ):

    if 'CSV' in labelname:
        if isinstance( data,str ):
            header, *rows = data.split("|")

            # 将表头和数据转换为列表
            header_list = header.split(",")
            rows_list = [row.split(",") for row in rows]

            # 将数据转换为 Pandas DataFrame
            ret = pd.DataFrame(rows_list, columns=header_list)

            # 打印 DataFrame
            # print(ret)
    else:
        ret = data
    return ret

from PIL import Image
import io
import base64

def image_to_base64(image_path):
    try:
        # 打开图片文件
        with Image.open(image_path) as img:
            # 将图片转换为字节流
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")  # 根据图片格式调整
            # 将字节流转换为Base64编码的字符串
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            return img_str
    except Exception as e:
        logging.info(f"图片处理失败: {e}")
        return None


import datetime
class WorkflowEngine:
    def __init__(self, flow_data ,work_path=None,execute_time = None ):
        logging.info('begin init workflow engine: %s %s',work_path,execute_time)
        self.flow_data = flow_data
        self.projectname    = flow_data.get('projectName')
        if execute_time!=None:
            self.execute_time = execute_time
        else:
            self.execute_time = 'T' + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")[2:]

        if work_path==None:
            proj_dir            = "projects";
            self.project_dir    = os.path.join(proj_dir, self.projectname)
            os.makedirs( self.project_dir )
        else:
            self.project_dir    = work_path

        self.nodes          = flow_data.get('nodes', [])
        self.edges          = flow_data.get('edges', [])
        self.G              = nx.DiGraph()
        self.results        = {}

        for node in self.nodes:
            self.G.add_node(node['id'], **node)
        for edge in self.edges:
            self.G.add_edge(edge['source'], edge['target'])

        self.entry_node_ids = [node for node in self.G.nodes() if self.G.in_degree(node) == 0 and  self.get_label_byId(node)  not in ['Result'] ]
        self.exit_node_ids  = [node for node in self.G.nodes() if self.G.out_degree(node) == 0 and self.get_label_byId(node) not in ['Result'] ]
        logging.info( 'Entry nodes: %s', self.entry_node_ids  )
        logging.info( 'Exit nodes: %s',  self.exit_node_ids   )

    def get_nodedata_byid(self,node_id):
        node = self.G.nodes[node_id]
        node_data = node.get('data', {})
        return node_data
    def get_label_byId(self,node_id):
        node = self.G.nodes[node_id]
        return node.get('label')
    def get_type_byId(self,node_id):
        node = self.G.nodes[node_id]
        return node.get('type')
    def subf_execute_save(self,node_label,node_id):

        logging.info("begin sub execute save")
        if not os.path.exists(self.project_dir):
            os.makedirs(self.project_dir)
        algo_labes  = [  'CSV',"StatM","Derive","MachineLearning","AutoML", "NeuralNet", "MultiModal", "TimeSeries"]
        if node_label in ['Preprocess',"StatM","Deduplicate",'KeyFeature', 'Derive', "DataSetSplit", "Fileter", "Append","Merge","dataSource","DataSource"]+algo_labes:
            try:
                logging.info("node_label:%s,node_id.keys(%s)",node_label,self.results[node_id].keys() )
                for key in self.results[node_id].keys():
                    logging.info("save node reslult key[%s],dest_project_dir[%s] type[%s]", key, self.project_dir, type(self.results[node_id][key]))
                    if isinstance(self.results[node_id][key], pd.DataFrame) == True :
                        file_path = os.path.join(self.project_dir,self.execute_time, node_id + "__" + key + ".csv")
                        logging.info("file_path:%s", file_path)
                        #columns = 'key,DType,MAE,MSE,STD,ABS_STD,R2,MAPE,max_diff,min_diff,Len,small_except_ratio,big_except_ratio'.split(',')
                        self.results[node_id][key].to_csv(file_path, index=False)
                    if key in ['mets_df']:
                        tmp_df           = copy.deepcopy(  self.results[node_id][key]    )
                        tmp_df['source'] = node_id
                        file_path        = os.path.join(  self.project_dir,  self.execute_time  ,"all"+"__"+key + ".csv" )
                        columns          = 'source,key,DType,MAE,MSE,STD,ABS_STD,R2,MAPE,max_diff,min_diff,Len'.split(',')
                        tmp_df[columns].to_csv( file_path ,index=False,mode='a')
                        del tmp_df
            except:
                logging.error(traceback.format_exc())
                logging.error("%s %s ", node_label, node_id)
        logging.info("finish sub execute save")
        return
    def execute(self,task='train',sample_dict={}):
        logging.info('######begin workflow execute')
        import datetime
        try:
            task_order = list( nx.topological_sort(self.G) )
        except nx.NetworkXUnfeasible:
            return {'error': 'The graph has a cycle, cannot determine task execution order.'}
        ret_={}
        execute_dir = os.path.join(  self.project_dir,self.execute_time)
        if os.path.exists(  execute_dir )==False:
            os.makedirs( execute_dir )
        import datetime
        logging.info("task_order:%s",task_order)
        for node_id in task_order:
            try:
                node       = self.G.nodes[node_id]
                node_type  = node.get('type')
                node_label = node.get('label')
                node_data  = node.get('data', {})

                if node_label =='Result': continue
                logging.info( 'begin node_id[%s] step,node_type[%s] node_label[%s]', node_id, node_type, node_label)
                logging.info( 'node_data:%s', node_data )

                inf_dict ={}
                if node_type == 'dataSource' :
                    self.results[node_id] = self.process_data_source(  node_id,node_label, node_data,task,sample_dict )
                elif node_label == 'Preprocess':
                    self.results[node_id] = self.preprocess_data(  node_id,node_data, task, inf_dict )

                elif node_label == 'Merge':
                    self.results[node_id] = self.process_merge(     node_id,node_data,task   )
                elif node_label in ['StatM','NeuralNet','AutoML','MultiModal','TimeSeries']:
                    self.results[node_id] = self.process_algorithm( node_id,node_data, task  )
                elif node_label == 'Derive':
                    self.results[node_id] = self.process_feature_derive(node_data, self.results,task)
                elif node_label == 'Append':
                    self.results[node_id] = self.process_append(node_id,node_data, task )
                elif node_label == 'Filter':
                    self.results[node_id] = self.process_filter(node_id,node_data, task)
                elif node_label == 'EDA':
                    self.results[node_id] = self.process_eda(node_id,node_data, task)
                elif node_label == 'Correlation':
                    self.results[node_id] = self.process_correlation_analysis(node_id,node_data, task)
                elif node_label == '数据分布':
                    self.results[node_id] = self.process_data_distribution(node_data, self.results)
                elif node_label in [  'KeyFeature' ]:
                    self.results[node_id] = self.process_feature_importance(node_data, self.results)
                elif node_label == "Rename":
                    self.results[node_id] = self.process_rename(node_id,node_data,task)

                elif node_label =='Deduplicate':
                    self.results[node_id] = self.process_Deduplicate(node_id,node_data,task)

                elif node_label =='Sample':
                    self.results[node_id] = self.process_sample(node_id,node_data,task)

                elif node_label =='TypeTransform':
                    self.results[node_id] = self.process_type_transform( node_id,node_data,task )

                elif node_label =="DataSetSplit":
                    self.results[node_id] = self.process_data_split(node_id, node_data, task)
                elif node_label =='Result':
                    continue
                elif node_label == 'Sort':
                    self.results[node_id] = self.process_sort( node_id,node_data,task )

                elif node_label == 'OnLinePredCtrl' and task =='predict':
                    self.results[node_id] = self.process_inlinePredCtrl(node_id, node_data, task)

                elif node_label =="ImageSource" :
                    self.results[node_id] = self.process_images_source(node_id, node_data, task,sample_dict )

                elif node_label =="ImageClassify" :
                    self.results[node_id] = self.process_images_algo(node_id, node_data, task,sample_dict )

                elif node_label =='ObjectDetect':
                    self.results[node_id] = self.process_image_detect(node_id, node_data, task,sample_dict)
                elif node_label =="ImageSegment":
                    self.results[node_id] = self.process_image_seg(node_id, node_data, task, sample_dict)
                else:
                    logging.info("unknow node_label[%s]",node_label)

                if task=="train" and node_label == 'Derive':
                    ret_[node_id] = { "status": "success", "message": "finish", "progress": 100,"columns":self.results[node_id]['columns'] }
                elif task=="train" and node_label == 'ImageSource':
                    ret_[node_id] = {"status": "success", "message": "%s data"%( self.results[node_id]['data_type']  ), "progress": 100}
                elif task == "train" and node_label == 'ImageClassify':
                    ret_[node_id] = {"status": "success", "message": "%s Accuray:%s" % (self.results[node_id]['alg_name'],round( float(self.results[node_id]['stats_df']['accuracy'].tolist()[-1]),2 )), "progress": 100}
                elif task == "train" and node_label == 'ObjectDetect':
                    ret_[node_id] = {"status": "success", "message": "mAP_50_95:%s" % ( self.results[node_id]['mAP_50_95'] ), "progress": 100}  # #result_dict['mAP_50_95'] = mAP_50_95

                elif task =='train' and node_label =='ImageSegment':
                    ret_[node_id] = {"status": "success", "progress": 100} # "message": "mAP_50_95:%s" % (self.results[node_id]['mAP_50_95']),

                else:
                    ret_[node_id] = { "status": "success", "message": "finish","progress":100 }

                # if task in ['predict','inference']:
                #     logging.info('%s : %s',node_id, str( self.results[node_id] )[:5] )  #['sample_df']

                if task in ['train']:   self.subf_execute_save( node_label,node_id)
                logging.info('finish step node_id[%s]', node_id)
            except:
                import traceback
                msg = traceback.format_exc()
                # if len(msg)>30:
                #     msg = msg[-40:]

                ret_[node_id] = {"status": "error", "message": 'detail in logfile', "progress": 0 }
                logging.info(str(msg) )
                logging.info("finish step node_id[%s]", node_id)
                return ret_
            # 其他节点类型处理
        if task=='predict':
            ret_={}
            for id in self.exit_node_ids:
                logging.info('id:%s',id)
                ret_[id] = { k:self.results[id][k]  for k in ['sample_df','preds_df' ,'Image' ] if k in self.results[id]  }
        logging.info('######finish workflow execute')
        return ret_

    def process_data_split(self,node_id, node_data, task):
        logging.info("begin process_data_split")
        pre_node_ids    = node_data.get('prenodeId')
        ret_dict        ={ }
        if node_data['config'].get("indieNode")!=None and node_data['config'].get('trainNode')!=None:
            logging.info("two node[%s] [%s] ",node_data['config'].get("trainNode"),node_data['config'].get("indieNoe")  )
            train_df = self.results[ node_data['config'].get("trainNode")  ]['df']
            indie_df = self.results[ node_data['config'].get("indieNode")  ]['df']
        else:
            logging.info("prenode id[%s]",pre_node_ids)
            pre_node_result = self.results.get(   pre_node_ids[0])
            pre_node_data   = self.get_nodedata_byid(pre_node_ids[0])
            pre_node_result =  self.results.get(  pre_node_ids[0]  )
            pre_node_data   =  self.get_nodedata_byid(pre_node_ids[0])

            #按比例拆分
            indie_ratio = float(  node_data['config'].get("splitPercentage",30))/100
            train_ratio = 1-indie_ratio #70%用于训练
            logging.info("trian ratio:%s indie_ratio:%s ",train_ratio,indie_ratio)
            logging.info("pre node:%s",pre_node_result.keys())
            df  = pre_node_result['df']
            if train_ratio >1 or train_ratio <0:
                train_ratio=0.7
            train_df = df.sample(frac=train_ratio,random_state=42)
            indie_df = df.drop(train_df.index)  #剩下的30%用于测试集

        ret_dict['train_df'] = train_df
        ret_dict['indie_df'] = indie_df

        logging.info("finish process data split")
        return ret_dict

    def process_inlinePredCtrl(self,node_id,node_data,task):
        if task =="train":
            logging.info("process_inlinePredCtrl cannot process train task")
            return None
        logging.info("begin process_inlinePredCtrl")
        pre_node_ids=node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result  = self.results[ pre_node_id ]
        logging.info("predict_id[%s]",pre_node_id)
        ret_dict   = {}
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ) and node_data['config'].get('sortConfig',None)!=None:
                logging.info("node_data.config:%s",node_data['config'])
                for k in node_data['config'].get('sortConfig'):
                    ret_dict[i] = pre_result[i].sort_values(  by= [k['column']],ascending= True if  k['order'] in ['asc'] else False )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_inlinePredCtrl")
        return ret_dict

    def process_images_source(self, node_id, node_data, task,sample_dict):
        logging.info('node_data:%s',node_data )
        import torchvision.datasets.mnist as mnist
        dataSourceType = node_data.get("config").get('dataSourceType', None)
        ret_dict = {}
        if task != 'predict':
            if dataSourceType=='classic'   :#data_type == 'mnist':
                classicDataset = node_data.get("config").get('classicDataset', None)
                if classicDataset in [ 'mnist','cifar10']:
                    if classicDataset =='mnist':
                        root = 'D:\\workspace\\data\\MNIST\\raw\\'
                        train_data              = mnist.read_image_file(os.path.join(root, 'train-images-idx3-ubyte'))
                        train_labels            = mnist.read_label_file(os.path.join(root, 'train-labels-idx1-ubyte'))
                        indie_data              = mnist.read_image_file(os.path.join(root, 't10k-images-idx3-ubyte'))
                        indie_labels             = mnist.read_label_file(os.path.join(root, 't10k-labels-idx1-ubyte'))
                    if classicDataset == 'cifar10':
                        from deepreg import load_cifar10
                        train_data, train_labels, indie_data, indie_labels = load_cifar10(  data_dir='E:\\ml_data\\cifar-10-batches-py')
                        logging.info("train_data shape %s",train_data.shape)

                    ret_dict['train_data']   = train_data
                    ret_dict['train_labels'] = train_labels
                    ret_dict['indie_data']   = indie_data
                    ret_dict['indie_labels'] = indie_labels
                    ret_dict['data_type']    = classicDataset
                    logging.info('%s  train_len[%s]  indie_len[%s] ',classicDataset,len(train_labels ) ,len( indie_labels )  )
        else:
            ret_dict = {}  # self.results[ node_id ]
            sample_df = sample_dict[node_id]
            ret_dict['sample_df'] = sample_df
            logging.info('sample_df:%s', sample_df)

        return ret_dict

    def process_images_algo(self, node_id, node_data, task,sample_dict={}):
        logging.info('begin images_algo')
        from deepreg import DeepRegWrapper
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]

        if task=='train':
            result_dict = {}
            alg_name        = node_data.get("config").get('image_algo', None)
            epoch           = node_data.get("config").get('epoch', 1)
            logging.info('%s ',alg_name )
            total_stat_df   = []
            # for alg_name in ['mask_rcnn', 'vgg', 'resnet18', 'mobilenet_v2', 'unet', 'detnet', 'fpn','r_fcn']:  # alexnet resnet18 mobilenet_v2 unet detnet
            logging.info('*** %s' % alg_name)
            clf = DeepRegWrapper(task='classification', name=alg_name, batch_size=128, num_classes=10, epochs=epoch,in_channels=3)
            clf.fit(pre_result['train_data'], pre_result['train_labels'])
            # total_stat_df.append(clf.stats_df)
            # total_stat = pd.concat(total_stat_df)
            result_dict['stats_df'] = copy.deepcopy(  clf.stats_df )
            result_dict['model']    = clf
            result_dict['alg_name'] = alg_name
        else:
            if 'sample_data' in pre_result:
                sample_data = pre_result['sample_data']
            if 'sample_df' in pre_result:
                sample_data = pre_result['sample_df']

            result_dict = self.results[node_id]
            clf         = result_dict['model']
            preds      = clf.predict( sample_data )

            result_dict['sample_df'] = preds
            logging.info('result:%s',preds)

        #total_stat.to_excel('stat_df2.xlsx')
        logging.info('end images_algo')
        return result_dict

    def get_project_path(self):
        proj_dir = "projects"
        proj_dir = os.path.join(proj_dir, self.projectname, self.execute_time)
        if not os.path.exists(proj_dir):
            os.makedirs(proj_dir)
        return proj_dir


    def process_image_detect(self, node_id, node_data, task,sample_dict={} ):
        logging.info(' task[%s]',task)
        logging.info("sample_dict keys %s",sample_dict.keys())
        mode            = node_data.get("config").get('mode', 'inference')

        model_path      = node_data.get("config").get('model_path') #,'./runs/detect/train2/weights/best.pt'
        epochs          = node_data.get("config").get('CVepochs',3)
        batch           = node_data.get("config").get('CVbatchSize',32)
        result_dict ={  }
        if  task=='train':
            dataset_path = node_data.get("config").get('dataset_yaml_path',None)
            yaml_content = node_data.get("config").get('CVdatasetYaml')

            if dataset_path==None:
                dataset_path = os.path.join( self.get_project_path(), 'dataset.yaml' )
                with open(dataset_path, 'w') as file:
                    file.write(yaml_content)

            from deepdetect import yolo_train
            results =  yolo_train(model_path ='./runs/detect/train2/weights/best.pt',
                       dataset_path          =dataset_path,
                       epochs=int(epochs),batch= int(batch),
                       project= self.get_project_path( ) )
            # result_dict['train_result'] = results
            if hasattr(results, 'results_dict'):
                # YOLOv5 的处理方式
                mAP_50 = results.results_dict.get('metrics/mAP50(B)')
                mAP_50_95 = results.results_dict.get('metrics/mAP50-95(B)')
                result_dict['mAP_50_95'] = mAP_50_95
            elif hasattr(results, 'metrics'):
                # YOLOv8 的处理方式
                mAP_50 = results.metrics.get('map50', None)
                mAP_50_95 = results.metrics.get('map', None)
            else:
                mAP_50 = None
                mAP_50_95 = None

        elif mode == 'inference' or task == 'predict' or task == 'inference':

            default_model_path = os.path.join(  self.get_project_path( ),'./runs/detect/train1/weights/best.pt' )
            if  os.path.exists(  default_model_path ):
                model_path  =    default_model_path
                logging.info('current dir has trained best.pt')
            logging.info('has load model@@')

            pre_node_ids = node_data.get('prenodeId')
            if pre_node_ids !=None:
                pre_node_id  = pre_node_ids[0]
                pre_result   = self.results[pre_node_id]

                if 'sample_image_path' in pre_result:
                    sample_image_path = pre_result['sample_image_path']
                elif  node_data.get("config").get('sample_image_path')!=None:
                    sample_image_path = node_data.get("config").get('sample_image_path')
            else:
                sample_image_path = os.path.join(  self.get_project_path( ) , "tmp.png" )
                if node_id in sample_dict:
                    pic_data = np.array( sample_dict[node_id] )
                    pic_data = pic_data.astype(np.uint8)
                    logging.info('pic_data shape %s',pic_data.shape)

                image_data = np.transpose(pic_data, (1, 2, 0))
                # 创建 PIL 图像
                from PIL import Image
                image = Image.fromarray(image_data)
                # 保存图像
                image.save( sample_image_path )
                logging.info("######saved pic path:%s",  sample_image_path )
            logging.info("######saved pic path:%s", sample_image_path)
            logging.info("####################################"  )
            from deepdetect import yolo_inference
            save_pic_path = os.path.join( self.get_project_path( ), '%s_result.jpg'% node_id)
            yolo_inference(
                model_path = model_path,  # 训练好的模型路径
                image_path = sample_image_path, #'./test.png' # 测试图像路径  'F:\\work\\hms_ml_project\\red.jpg',#
                result_path= save_pic_path    # 结果保存路径
            )
            image_base64            = image_to_base64(save_pic_path)
            result_dict['Image']    = image_base64

        else:
            logging.info("unknown process_image_detect mode situation")


        return result_dict

    def process_image_seg(self, node_id, node_data, task,sample_dict={}):
        result_dict = {}
        logging.info("begin process_image_seg [%s]", task)
        model_path  = node_data.get("config").get('model_path') #, './yolov8n-seg.pt'
        epochs      = int( node_data.get("config").get('epochs', 3) )
        batch       = int( node_data.get("config").get('batchSize', 16) )

        if task == 'train':
            dataset_path = node_data.get("config").get('dataset_yaml_path', None)
            yaml_content = node_data.get("config").get('yoloDatasetYaml')

            if dataset_path == None:
                dataset_path = os.path.join(self.get_project_path(), 'dataset.yaml')
                with open(dataset_path, 'w') as file:
                    file.write(yaml_content)

            from deepseg import  yolov5_seg_train
            yolov5_seg_train(
                dataset_path= dataset_path, #'./dataset.yaml',  # 数据集配置文件
                model_name  = './yolov8n-seg.pt',  # 预训练模型
                epochs      = epochs,
                imgsz       = 640,
                batch       = batch,
                device      = 'cuda',
                project     = self.get_project_path(),#'./segrun',  # 指定保存目录的父目录
                name        = node_id    #    'face_segmentation_exp'  # 指定实验名称
            )
            logging.info("train task finish")
        else:
            default_model_path = os.path.join(self.get_project_path(),node_id,"weights","best.pt")
            if os.path.exists(default_model_path):
                model_path = default_model_path
                logging.info('current dir has trained best.pt [%s]',default_model_path)
            else:
                logging.info("path %s not exits",default_model_path )
            logging.info('has load model@@')

            pre_node_ids = node_data.get('prenodeId')
            if pre_node_ids != None and len(pre_node_ids)>0:
                pre_node_id = pre_node_ids[0]
                pre_result = self.results[pre_node_id]

                if 'sample_image_path' in pre_result:
                    sample_image_path = pre_result['sample_image_path']
                elif node_data.get("config").get('sample_image_path') != None:
                    sample_image_path = node_data.get("config").get('sample_image_path')
            else:
                sample_image_path = os.path.join(self.get_project_path(), "tmp.png")
                if node_id in sample_dict:
                    pic_data = np.array(sample_dict[node_id])
                    pic_data = pic_data.astype(np.uint8)
                    logging.info('pic_data shape %s', pic_data.shape)

                image_data = np.transpose(pic_data, (1, 2, 0))
                from PIL import Image
                image = Image.fromarray(image_data)
                # 保存图像
                image.save(sample_image_path)
                logging.info("######saved pic path:%s", sample_image_path)
            logging.info("######saved pic path:%s", sample_image_path)
            logging.info("####################################")
            from deepseg import yolov5_seg_inference
            save_pic_path = os.path.join(self.get_project_path(), '%s_result.jpg' % node_id)
            yolov5_seg_inference(
                model_path=model_path,  # 训练好的模型路径
                image_path=sample_image_path,  # './test.png' # 测试图像路径  'F:\\work\\hms_ml_project\\red.jpg',#
                result_path=save_pic_path  # 结果保存路径
            )
            image_base64 = image_to_base64(save_pic_path)
            result_dict['Image'] = image_base64
        return result_dict

    def process_sort(self,node_id,node_data,task):
        logging.info("begin process_sort")
        pre_node_ids=node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result  = self.results[ pre_node_id ]
        logging.info("predict_id[%s]",pre_node_id)
        ret_dict   = {}
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ) and node_data['config'].get('sortConfig',None)!=None:
                logging.info("node_data.config:%s",node_data['config'])
                for k in node_data['config'].get('sortConfig'):
                    ret_dict[i] = pre_result[i].sort_values(  by= [k['column']],ascending= True if  k['order'] in ['asc'] else False )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_sort")
        return ret_dict

    def process_rename(self,node_id,node_data,task):
        logging.info("begin process_df_rename")
        pre_node_ids=node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result  = self.results[ pre_node_id ]
        logging.info("predict_id[%s]",pre_node_id)
        ret_dict   = {}
        rename_dict= node_data['config']['renameMapping']
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ):
                ret_dict[i] = pre_result[i].rename( columns =rename_dict )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_df_rename")
        return ret_dict

    def process_Deduplicate(self,node_id,node_data,task):
        logging.info("begin process_Deduplicate")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("predict_id[%s]", pre_node_id)
        ret_dict = {}
        columns_ = node_data['config']['deduplicateColumns']  #
        keep_    = node_data['config']['keepMethod']  #'keepMethod'
        for i in pre_result:
            if isinstance( pre_result[i],pd.DataFrame ):
                ret_dict[i] = pre_result[i].drop_duplicates( subset = columns_,keep=keep_ )
        # logging.info("ret_dict:%s",ret_dict )
        logging.info("finish process_df_rename")
        return ret_dict

    def process_sample(self, node_id, node_data, task):
        logging.info("begin process_sample")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("pre_node_id[%s]", pre_node_id)
        ret_dict = {}

        sample_type = node_data['config'].get('sampleType', 'whole')
        sample_method = node_data['config'].get('sampleMethod', 'downsample')
        sample_ratio = node_data['config'].get('sampleRatio', 10) / 100
        sample_column = node_data['config'].get('sampleColumn')
        sample_condition = node_data['config'].get('sampleCondition')
        sample_condition_value = node_data['config'].get('sampleConditionValue')

        for key, df in pre_result.items():
            if isinstance(df, pd.DataFrame):
                if sample_type == 'whole':
                    if sample_method == 'downsample':
                        ret_dict[key] = df.sample(frac=sample_ratio)
                    else:
                        ret_dict[key] = df.sample(frac=sample_ratio, replace=True)
                else:
                    if sample_condition == 'eq':
                        filtered_df = df[df[sample_column] == sample_condition_value]
                    elif sample_condition == 'lt':
                        filtered_df = df[df[sample_column] < float(sample_condition_value)]
                    elif sample_condition == 'gt':
                        filtered_df = df[df[sample_column] > float(sample_condition_value)]
                    elif sample_condition == 'between':
                        lower, upper = map(float, sample_condition_value.split(','))
                        filtered_df = df[(df[sample_column] >= lower) & (df[sample_column] <= upper)]

                    if sample_method == 'downsample':
                        ret_dict[key] = filtered_df.sample(frac=sample_ratio)
                    else:
                        ret_dict[key] = filtered_df.sample(frac=sample_ratio, replace=True)
        logging.info("finish process_sample")
        return ret_dict

    def process_type_transform(self, node_id, node_data, task):
        logging.info("begin process_transform")
        pre_node_ids = node_data.get('prenodeId')
        pre_node_id = pre_node_ids[0]
        pre_result = self.results[pre_node_id]
        logging.info("pre_node_id[%s]", pre_node_id)
        ret_dict = {}

        transform_configs = node_data['config'].get('transformConfigs', [])

        for key, df in pre_result.items():
            if isinstance(df, pd.DataFrame):
                for config in transform_configs:
                    column = config.get('column')
                    transform_type = config.get('type')
                    param = config.get('param')
                    if column and transform_type:
                        if transform_type == 'string_to_number':
                            df[column] = pd.to_numeric(df[column], errors='coerce')
                        elif transform_type == 'number_to_string':
                            df[column] = df[column].astype(str)
                        elif transform_type == 'date_format':
                            df[column] = pd.to_datetime(df[column], format=param, errors='coerce')
                        elif transform_type == 'custom':
                            try:
                                df[column] = df[column].apply(eval(param))
                            except Exception as e:
                                logging.error(f"Custom transform failed: {e}")
                ret_dict[key] = df

        logging.info("finish process_transform")
        return ret_dict

    def process_data_source(self, node_id,node_label, node_data,task='train',sample_dict={}):
        logging.info('begin process_data_source node_label[%s]  node_id[%s] task[%s]',node_label,node_id,task)
        project_dir     = self.project_dir #os.path.join(proj_dir, self.projectname)
        if not os.path.exists(project_dir):
            os.makedirs(project_dir)
        # 处理数据源节点
        ret_dict = {}
        if task !='predict':
            if node_label=='CSV':
                file_path       = os.path.join(project_dir,  node_id+ '__' +node_data.get('config').get('filename'))
                if file_path.endswith(".csv"):
                    df              = pd.read_csv(file_path,    sep=node_data.get('delimiter', ','),index_col=False )
                elif file_path.endswith(".xlsx"):
                    df             = pd.read_excel(file_path,index_col=False)
                else:
                    logging.info("unknow file type")
                logging.info('loaded df shape[%s]',df.shape)
                ret_dict        = {'df':df}
            elif node_label =="S3":
                from unkops import Bucket
                ds_id           = node_data.get("config").get("dsId")
                train_file      = node_data.get("config").get("trainFileName")
                indie_file      = node_data.get("config").get("indieFileName")
                logging.info("begin download dataserver data ds_id[%s] train_file[%s]  indie_file[%s]"%
                             (ds_id,train_file,indie_file ) )
                client = Bucket(ini_conf["minioexplore"]['url'],ini_conf["minioexplore"]['access_key'],ini_conf["minioexplore"]['secret_key'])

                trainFileName_file_path = os.path.join(project_dir,f'{node_id}__{train_file}')
                indieFileName_file_path = os.path.join(project_dir,f'{node_id}__{indie_file}')

                if train_file!=None:
                    logging.info("download %s %s",train_file,trainFileName_file_path)
                    client.download_file(bucket_name="mlapc.dataserver.new",file="/%s/%s"%(ds_id,train_file),     file_path=trainFileName_file_path)
                if indie_file != None:
                    logging.info("download %s %s", indie_file, indieFileName_file_path)
                    client.download_file(bucket_name="mlapc.dataserver.new", file="/%s/%s" % (ds_id, indie_file), file_path=indieFileName_file_path )
                ret_dict = {}
                ret_dict['train_df'] = pd.read_csv(trainFileName_file_path,sep=node_data.get("delimiter",","),index_col=False)
                ret_dict['indie_df'] = pd.read_csv(indieFileName_file_path,sep=node_data.get("delimiter",","),index_col=False)

            elif node_label =="URL":

                trainFileName = node_data.get("config").get("trainFileName")
                indieFileName = node_data.get("config").get("indieFileName")
                fileType      = node_data.get("config").get("fileType")
                singleFileUrl = node_data.get("config").get("singleFileUrl")

                nodeId          = node_data.get("config").get('nodeId')
                sep             = node_data.get("config").get('sep', ',')
                proj_dir        = "projects";
                project_dir     = os.path.join(proj_dir, self.projectname)
                logging.info("####node_label %s fileType %s ", node_label,fileType )

                if fileType in ['single', 'train_test']:
                    if fileType == 'single':
                        urlfile = singleFileUrl
                        tmpfile = os.path.join(self.project_dir, '%s__df.csv' % nodeId)  #
                        if os.path.exists( tmpfile ) ==False :download_file_from_url(singleFileUrl, tmpfile)
                        ret_dict['df'] = pd.read_csv(tmpfile, sep=sep)
                    elif fileType == 'train_test':
                        urlfile = indieFileName
                        tmpfile = os.path.join(self.project_dir, '%s__indie_df.csv' % nodeId)
                        if os.path.exists( tmpfile ) ==False :download_file_from_url(urlfile, tmpfile)
                        ret_dict['indie_df'] = pd.read_csv(tmpfile,sep=sep)

                        urlfile = trainFileName
                        tmpfile = os.path.join(self.project_dir, '%s__train_df.csv' % nodeId)
                        if os.path.exists( tmpfile ) ==False : download_file_from_url(urlfile, tmpfile)
                        ret_dict['train_df'] = pd.read_csv(tmpfile, sep=sep)
                    else:
                        logging.info("unknow filetype[%s]", fileType)
        else:
            ret_dict                = {}#self.results[ node_id ]
            sample_df               = sample_dict[ node_id ]
            ret_dict['sample_df']   = sample_df
            logging.info('sample_df:%s',sample_df)
        logging.info('finish process_data_source ')
        return ret_dict

    def preprocess_data(self,node_id, node_data, task='train',sample_dict={}):
        # 处理类型设置节点
        pre_node_ids        = node_data.get('prenodeId')
        logging.info('prenode id %s ', pre_node_ids)
        pre_node_label      = self.get_label_byId( pre_node_ids[0] )
        pre_node_type       = self.get_type_byId(  pre_node_ids[0] )
        # 获取前一个节点的数据结构
        pre_node_result     = self.results.get(   pre_node_ids[0]     )
        pre_node_data       = self.get_nodedata_byid( pre_node_ids[0] )
        logging.info('pre_node_data:%s',pre_node_data)
        pre_node_columns    = pre_node_data['config']['columns']
        logging.info('columns:%s',pre_node_columns)
        #from auto_ml_v2 import data_process, map_to_localargs
        from automl_utils    import  map_to_localargs
        from data_preprocess import  data_process
        pre_dict = self.get_pre_data(task=task, pre_node_type=pre_node_type, pre_node_label=pre_node_label,pre_node_data= pre_node_result)
        logging.info("pre_dict keys:%s",pre_dict.keys() )
        ret_dict = {}
        if task =='train':
            #df = self.results[node_data.get('node_id')]
            preprocess_json  ={ }
            columnTypes     = node_data['config'].get('columnTypes',[ ] )
            batch_group_dict={ }
            for k in columnTypes:
                if columnTypes[k] != 'no':
                    if k in node_data['config']['batchFill']:
                        v = node_data['config']['batchFill'][k]
                        batch_group_dict.setdefault("batchfill",[])  #node_data['config']['batchFill'][k]
                        batch_group_dict['batchfill'].append(   "%s|%s|%s"%( k,v,columnTypes[k] )  )
                    if k in node_data['config']['groupFill']:
                        v = node_data['config']['groupFill'][k]
                        batch_group_dict.setdefault("groupfill",[])  # node_data['config']['batchFill'][k]
                        batch_group_dict['groupfill'].append("%s|%s|%s" % (k, v, columnTypes[k]))
                    tmp_dict = {'data_type': columnTypes[k]}
                    if k in node_data['config']['outlierHandling']:
                        tmp_dict['outlier'] = node_data['config']['outlierHandling'][k]
                    if k in node_data['config']['missingFill']:
                        tmp_dict['fillna'] = node_data['config']['missingFill'][k]
                    if k in node_data['config']['preprocessing']:
                        tmp_dict['proc'] =  node_data['config']['preprocessing'][k]
                    preprocess_json[k] = copy.deepcopy(tmp_dict)

            logging.info("from preprocess_json:%s",preprocess_json)
            params   = map_to_localargs(   {"preprocess_json":preprocess_json,"batchfill": batch_group_dict.get("batchfill",None) ,"groupfill":batch_group_dict.get("groupfill",None) } )
            logging.info("params:%s",params)
            ret_dict['params']      = params
            ret_dict['columnTypes'] = columnTypes
            ret_dict['pre_node_columns'] = pre_node_columns

            if  'df' in pre_dict:
                df, p_dict          = data_process(pre_dict['df'],keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=True, data_type="train", use_mlflow=None)
                ret_dict['df']      = df
                ret_dict['p_dict']  = p_dict
            elif 'train_df'  in pre_dict:
                train_df, p_dict    = data_process(pre_dict['train_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=True, data_type="train", use_mlflow=None)
                ret_dict['train_df']= train_df
                ret_dict['p_dict']  = p_dict

                if "test_df" in pre_dict and pre_dict['test_df'] is not None:
                    test_df             = data_process( pre_dict['test_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params,if_train= False, preprocess_dict=p_dict, data_type="test", use_mlflow=None )
                    ret_dict['test_df'] = test_df
                if 'indie_df' in pre_dict  and pre_dict['indie_df'] is not None:
                    indie_df             = data_process( pre_dict['indie_df'],keys=[], xcols=pre_node_columns, ycol=None, params=params, if_train=False, preprocess_dict=p_dict, data_type="indie", use_mlflow=None)
                    ret_dict['indie_df'] = indie_df
            else:
                logging.info("unknow prednode data")
        else:
            if 'sample_df'  in pre_dict :
                ret_dict= self.results[node_id]
                params  = self.results[node_id]['params']
                p_dict  = self.results[node_id]['p_dict']
                col_dict= self.results[node_id]['columnTypes']
                sample_df             = data_process( pre_dict['sample_df'], keys=[], xcols=pre_node_columns, ycol=None, params=params,if_train= False, preprocess_dict=p_dict, data_type="test", use_mlflow=None,type_dict=col_dict )
                ret_dict['sample_df'] = sample_df
        return  ret_dict


    def process_merge(self,node_id, node_data, task):
        # 处理Merge节点
        logging.info("begin process_merge")
        left_df     = self.results[ node_data['config']['leftNode']   ]['df']
        right_df    = self.results[ node_data['config']['rightNode']  ]['df']
        merge_keys = node_data['config']['mergeKeys']   #.get('merge_keys', [])
        merged_df = pd.merge(left_df, right_df, on=merge_keys)
        logging.info('merged_df shape[%s]',merged_df.shape)
        if task !="predict":
            ret_dict = {'df':merged_df}
        else:
            ret_dict = {'sample_df':merged_df}
        logging.info("finish process_merge")
        return ret_dict

    def get_pre_data(self,task,pre_node_type,pre_node_label,pre_node_data):
        if task != 'predict':

            if pre_node_label == 'CSV' or 'df' in pre_node_data:
                df      = pre_node_data.get('df')
                ret_dict= {"df":df}
            elif pre_node_label == 'DataServer':
                if "train_df" in pre_node_data:
                    train_df    = pre_node_data.get('train_df')
                    indie_df    = pre_node_data.get('indie_df', pd.DataFrame())
                    ret_dict    = {"train_df":train_df,"indie_df":indie_df}
                elif "df" in pre_node_data:
                    train_df = pre_node_data.get("df")
                    test_df  = pre_node_data.get('df', pd.DataFrame())
                    indie_df = pre_node_data.get('df', pd.DataFrame())
                    ret_dict ={"train_df":train_df,"test_df":test_df,"indie_df":indie_df}
                else:
                    logging.info("has no DataServer data")
            else:
                if "train_df" in pre_node_data:
                    train_df = pre_node_data.get('train_df')
                    ret_dict = {"train_df": train_df}
                    if "indie_df" in pre_node_data:
                        indie_df                = pre_node_data.get('indie_df')
                        ret_dict['indie_df']    = indie_df
                    if "test_df" in pre_node_data:
                        test_df                 = pre_node_data.get('test_df')
                        ret_dict['test_df']     = test_df
                elif 'df' in pre_node_data:
                    df = pre_node_data.get("df")
                    ret_dict = {"df":df}
                else:
                    logging.info("unknow pre_node_label,has no data,pre_data:%s",pre_node_data.keys())
        else:
            sample_df = pre_node_data.get('sample_df')
            ret_dict  = {'sample_df': sample_df}
        return ret_dict

    def process_algorithm(self, node_id,node_data, task=None):
        # 处理传统算法节点
        from  auto_ml_v2 import get_train_model, evaluate_,str_to_list,multi_models_predicts
        logging.info('begin process_algorithm')

        xcols       = node_data.get('config').get('xColumns')
        ycol        = node_data.get('config').get('yColumn')
        keys        = node_data.get('config').get('algoKeys',[])
        if keys in [None,'NoneType']: keys=[]

        if xcols == None or xcols =="":
            continuousxcolumns = node_data.get('config').get("continuousxColumns",[])
            categoriesxcolumns = node_data.get('config').get("categoriesxColumns",[])
            textxcolunns       = node_data.get('config').get("textxColumns",[])
            imagexcolunns      = node_data.get('config').get("imagexColumns",[])
            xcols = continuousxcolumns + categoriesxcolumns + textxcolunns + imagexcolunns

        algorithm   = node_data.get('config').get('Algorithm')
        logging.info('keys[%s]  X[%s] y[%s] algo[%s] ',keys, xcols, ycol, algorithm)
        select_cols = keys+ str_to_list(ycol) + xcols
        logging.info('select_cols:%s',select_cols)
        pre_node_ids    = node_data.get('prenodeId');                  logging.info('prenode id[%s]', pre_node_ids)
        pre_node_label  = self.get_label_byId( pre_node_ids[0] )
        pre_node_type   = self.get_type_byId(  pre_node_ids[0] )
        # 获取前一个节点的数据结构
        pre_node_data   = self.results.get( pre_node_ids[0] )
        logging.info('pre_node_data:%s',pre_node_data.keys() )

        if pre_node_data is None:
            logging.error( 'No data found for prenode id[%s]', pre_node_ids[0] )
            return {'error':'prenode id[%s] no data'%pre_node_data[0] }

        logging.info('x[%s] y[%s] algo[%s]', xcols, ycol, algorithm)  # 创建 argparse.Namespace 对象并填充参数
        if task != 'predict':
            pre_dict = self.get_pre_data( task,pre_node_type,pre_node_label,pre_node_data )
            train_df ,test_df,indie_df = pre_dict.get('train_df',None),pre_dict.get('test_df',None),pre_dict.get('indie_df',None) #['test_df'] indie_df  ['indie_df']
            if  train_df is  None and test_df is  None and indie_df is  None :
                logging.error('Missing train_df, test_df, or indie_df in prenode data')
                if 'df' not in pre_dict:
                    return {'error': 'no train/test/indie data %s'%pre_node_label[0] }
                else:
                    df = pre_dict['df']
                    train_df,indie_df = train_test_split(df,train_size=0.8)
                    train_df,test_df  = train_test_split(train_df,train_size=0.8)
                    logging.info("dataset len train[%s] test[%s] indie[%s]",len(train_df),len(test_df),len(indie_df))
            if test_df is None and (train_df is not None and indie_df is not None):
                test_df  = train_df.sample(frac = 0.2,random_state =42 )
                train_df = train_df.drop( test_df.index  )
            if len(train_df) != 0:   train_df = train_df[select_cols]
            if len(test_df)  != 0:   test_df  = test_df[select_cols]
            if len(indie_df) != 0  :
                if set( str_to_list(ycol) ) & set( indie_df.columns )!=set( str_to_list(ycol) ):
                    indie_df = indie_df[xcols]
                else:
                    indie_df = indie_df[select_cols]

            import argparse
            params              = argparse.Namespace()
            params.mode = node_data.get('config').get('AlgoMode', 'quick')  # 默认模式为 'quick'
            params.model_type   = node_data.get('config').get('AlgoType', 'reg')  # 默认模型类型为 'reg'
            params.algo_name    = algorithm
            params.tuning_json = node_data.get('config').get('tuning_json', None)
            params.search_algo = node_data.get('config').get('search_algo', 'grid')

            params.xcols                    = xcols
            params.continuousxcolumns       = node_data.get('config').get("continuousxColumns",None )
            params.categoriesxcolumns       = node_data.get('config').get("categoriesxColumns", None)
            params.textxcolumns             = node_data.get('config').get("textxColumns", None      )
            params.imagexcolumns            = node_data.get('config').get("imagexColumns", None     )
            params.num_continuousxcolumns  = len(params.continuousxcolumns) if params.continuousxcolumns !=None else 0
            params.num_categoriesxcolumns  = len(params.categoriesxcolumns) if params.categoriesxcolumns !=None else 0
            params.num_textxcolumns        = len(params.textxcolumns)       if params.textxcolumns       !=None else 0
            params.num_imagexcolunns       = len(params.imagexcolumns)      if params.imagexcolumns      !=None else 0

            models_dict, model_best_params = get_train_model( params, train_df, xcols, ycol )
            logging.info('models dict keys **********:%s', models_dict.keys()    )
            mets_df, pred_df = evaluate_(params, models_dict, train_df, test_df, indie_df, keys, xcols, ycol)
            saved_mode_dict                     = {}
            saved_mode_dict['models_dict']      = models_dict
            saved_mode_dict['mets_df']       = mets_df
            saved_mode_dict['pred_df']          = pred_df

        else:
            sample_df = pre_node_data.get('sample_df')
            if  sample_df is  None:
                logging.error('predict sample_df is None')
                return { 'error': 'no predict sample data %s' % pre_node_label[0] }
            if len(sample_df) != 0:
                sample_df = sample_df[select_cols]
            else:
                logging.error('predict sample_df len is 0')
                return { 'error': 'no predict sample data %s' % pre_node_label[0] }

            saved_mode_dict  =  self.results[node_id]
            models_dict      =  saved_mode_dict['models_dict']
            preds            =  multi_models_predicts( models_dict, sample_df, keys, xcols, ycol, deploy=True)
            saved_mode_dict['sample_df'] = preds

        logging.info('finish process_algorithm')
        return saved_mode_dict

    def process_feature_derive(self, node_data, results,task="train"):
        # 处理特征衍生节点
        derive_func = node_data.get('config',{}).get('deriveFunc')
        logging.info("derive_func:%s",derive_func)

        pre_node_ids = node_data.get('prenodeId');
        logging.info('prenode id[%s]', pre_node_ids)
        pre_node_label  = self.get_label_byId(pre_node_ids[0])
        pre_node_type   = self.get_type_byId(pre_node_ids[0])
        pre_node_data   = self.results.get(pre_node_ids[0])
        if pre_node_ids[0] not in results:
            return {'error': 'Input node data not found'}
        pre_dict        = self.get_pre_data(task, pre_node_type, pre_node_label, pre_node_data)
        ret_            = {  }
        import re
        function_name = re.findall(r"^def +(.+?)\(", derive_func)[0]
        exec(derive_func, globals())
        logging.info("run func:%s", function_name)
        if not function_name:
            return jsonify({'error': 'No function definition found in the code'}), 400

        for f in ['df','train_df','indie_df','test_df','sample_df']:
            logging.info('pre keys:%s', pre_dict.keys() )
            if f not in pre_dict:
                logging.info('filter %s',f)
                continue
            result = eval(function_name)(pre_dict[f])
            ret_[f]= result
            if 'columns' not in ret_ and task=='train': ret_['columns'] = list(ret_[f].columns)

        return ret_

    def process_append(self, node_id, node_data, task="task"):
        # 处理Append节点
        logging.info('begin process_append')
        node_ids = node_data.get( "prenodeId",[ ] )

        if not node_ids :
            return {'error': 'Node IDs or results not provided'}
        if task != "predict":
            dfs = [  self.results[node_id  ]['df'] for node_id in node_ids if node_id in self.results        ]
        else:
            dfs = [  self.results[node_id  ]['sample_df'] for node_id in node_ids if node_id in self.results ]
        if not dfs:
            return {'error': 'No valid dataframes found'}

        appended_df = pd.concat(dfs, ignore_index=True)
        if task !="predict":
            ret_dict = {'df':appended_df }
        else:
            ret_dict = {'sample_df':appended_df}
        return ret_dict

    def process_filter(self, node_id,node_data,task="train"):
        # 处理筛选节点
        logging.info('begin process_filter')
        filter_columns  = node_data['config'].get("columns")

        pre_node_ids    = node_data.get('prenodeId')
        logging.info('prenode id[%s]', pre_node_ids)
        pre_node_label  = self.get_label_byId(pre_node_ids[0])
        pre_node_type   = self.get_type_byId(pre_node_ids[0])
        pre_node_data   = self.results.get(pre_node_ids[0])
        logging.info('pre_node_data:%s', pre_node_data.keys())

        if pre_node_data is None:
            logging.error('No data found for prenode id[%s]', pre_node_ids[0])
            return {'error': 'prenode id[%s] no data' % pre_node_data[0]}
        ret_dict = self.get_pre_data( task,pre_node_type,pre_node_label,pre_node_data )
        for i in ret_dict:
            if isinstance( ret_dict[i],pd.DataFrame ):
                ret_dict[i] = ret_dict[i][ filter_columns ]
        logging.info('finish process_filter')
        return ret_dict

    def process_eda(self, node_id,node_data,task="train"):
        # 处理EDA分析节点
        logging.info("begin process_eda")
        if task == "train":
            pre_node_ids = node_data.get("prenodeId")[0]
            tmp_file    = './%s.csv'%node_id
            file_path = os.path.join(self.project_dir, self.execute_time,node_id + '__' + "eda.html")
            if 'df' in self.results[pre_node_ids]:
                self.results[pre_node_ids]['df'].to_csv(tmp_file,index=False)
            elif "train_df" in self.results[pre_node_ids]:
                self.results[pre_node_ids]['train_df'].to_csv(tmp_file,index=False)
            else:
                logging.info("has no data")
            cmd_str = ''' python eda_ops.py --input_file %s --output %s '''%(tmp_file,file_path)
            logging.info( "cmd:%s",cmd_str )
            os.system(cmd_str)
        return {}

    def process_correlation_analysis(self, node_id,node_data,task="train"):
        # 处理相关性分析节点
        logging.info("begin process_correlation_analysis")
        if task=="train":
            pre_node_ids = node_data.get("prenodeId")[0]
            file_path =   os.path.join(self.project_dir, node_id + "__correlation_matrix.csv")
            corr_columns = node_data['config'].get("correlationColumns",[])
            if 'df' in self.results[pre_node_ids]:
                tmp_df = self.results[pre_node_ids]['df']
            elif "train_df" in self.results[ pre_node_ids ]:
                tmp_df = self.results[ pre_node_ids ]['train_df']
            else:
                logging.info('has no data')
            corr_matrix = tmp_df[ corr_columns ].corr( )
            corr_matrix.to_csv('%s'%file_path,index=True)
        logging.info("finish process_correlation_analysis")
        return


    def process_data_distribution(self, node_data, results):
        # 处理数据分布节点
        columns = node_data.get('columns')
        input_node_id = node_data.get('input_node_id')

        if input_node_id not in results:
            return {'error': 'Input node data not found'}

        df = results[input_node_id]

        if not columns or not all(col in df.columns for col in columns):
            return {'error': 'Invalid columns provided'}

        distribution_stats = df[columns].describe(include='all').to_dict()
        return distribution_stats


    def process_feature_importance(self, node_data, results):
        logging.info('begin process_feature_importance')
        # 处理特征重要性节点
        xcolumns = node_data['config'].get('featureImportanceXColumns')
        ycolumn  = node_data['config'].get('featureImportanceYColumn')
        pre_node_ids = node_data.get("prenodeId")[0]

        logging.info('%s %s %s',xcolumns,ycolumn,pre_node_ids)
        if pre_node_ids not in results:
            return {'error': 'Input node data not found'}

        if 'df' in self.results[pre_node_ids]:
            df = self.results[pre_node_ids]['df']
        elif "train_df" in self.results[pre_node_ids]:
            df = self.results[pre_node_ids]['train_df']
        else:
            logging.info('has no data')

        if not xcolumns or not all(col in df.columns for col in xcolumns):
            return {'error': 'Invalid columns provided'}

        # 这里假设使用随机森林来计算特征重要性
        X = df[xcolumns]
        y = df[ ycolumn  ]  # 假设目标列名为 'target'
        model = RandomForestRegressor()
        model.fit(X, y)
        importance = model.feature_importances_
        #importance_dict = dict(zip(columns, importance))

        # 将特征重要性组织成 DataFrame
        importance_df = pd.DataFrame({
            'Feature': xcolumns,
            'Importance': importance
        })

        # 按重要性排序（可选）
        importance_df = importance_df.sort_values(by='Importance', ascending=False)
        ret_ = { 'importance_df':importance_df }
        logging.info("importance_df:\n%s", importance_df)

        logging.info('finish process_feature_importance')
        return ret_

# def  predict(agent,input_dict):
#     for k in input_dict:
#         input_dict[k]= predict_data_trans(  input_dict[k],k)
#     ret_result = agent.execute(task='predict', sample_dict=input_dict)
#     exit_nodeid= agent.exit_node_ids
#     nodedata   = agent.get_nodedata_byid( exit_nodeid[0]  )
#     ycol       = nodedata[  ]
#     algos      = nodedata[  ]
#     algorithm = node_data.get('config').get('Algorithm')
#     return ret_result

# import joblib
# def load_ai_agent( user_id,proj_name ):
#     import unkops
#     client = unkops.Bucket(ini_conf['minioexplore']['url'], ini_conf['minioexplore']['access_key'], ini_conf['minioexplore']['secret_key'])
#     dest_file = './tmp.ckp'
#     client.download_file(bucket_name='mlapc', file='/projects/%s/%s/%s_engine.ckp' % (user_id, proj_name, proj_name), file_path=dest_file)
#     ai_agent = joblib.load(dest_file)
#     return ai_agent

global ai_agent
def predict_( agent,  data_dict  ):
    for k in data_dict:
        data_dict[k]= predict_data_trans(  data_dict[k],k)
    ret_result  = agent.execute( task='predict', sample_dict=data_dict )
    exit_nodeid = agent.exit_node_ids
    node_data   = agent.get_nodedata_byid(exit_nodeid[0])

    xcols       = node_data.get('config').get('xColumns')
    ycol        = node_data.get('config').get('yColumn')
    algorithm   = node_data.get('config').get('Algorithm')
    logging.info("ret_result:%s",ret_result.keys() )
    if exit_nodeid[0] in ret_result:
        logging.info("node id[%s] ret_result keys:%s",exit_nodeid[0], ret_result[ exit_nodeid[0] ].keys())

        if 'Image' in  ret_result[ exit_nodeid[0] ]:
            pred_result = {
                "image": f"data:image/png;base64,%s"%ret_result[exit_nodeid[0]]['Image']  # 根据图片格式调整MIME类型
            }
        elif 'sample_df' in ret_result[ exit_nodeid[0] ] or 'sample_data' in ret_result[ exit_nodeid[0] ]:
            if 'sample_df' in ret_result[ exit_nodeid[0] ]:
                pred_result = ret_result[ exit_nodeid[0] ]['sample_df']
            if 'sample_data' in ret_result[ exit_nodeid[0] ]:
                pred_result = ret_result[ exit_nodeid[0] ]['sample_data']
            logging.info("type:%s",type(pred_result))
            if isinstance( pred_result,pandas.DataFrame ):
                pred_result =pred_result.reset_index().to_json()
            else:

                logging.info("not pandas dataframe")

            # else :
            #
            #     pred_result = ret_result[exit_nodeid[0]]['sample_df'][ycol]  # .to_json()

    else:
        pred_result="no result"
    # ret_dict  = ai_agent.predict( data_dict )
    return pred_result

import joblib
def set_args():
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument('--task',   default='train',    type=str,required=False )
    parser.add_argument('--stdin',  action='store_true',default=False)  # 0.0.0.0
    parser.add_argument('--flowdata_file', default='',  type=str,required=False  ) #0.0.0.0
    parser.add_argument('--host', default='0.0.0.0', type=str, required=False)
    parser.add_argument('--work_path',    default=None,     type=str,required=False )
    parser.add_argument('--execute_time',  default=None,       type=str,required=False )
    parser.add_argument('--load_file', default='projects\\test_diamonds_feature\\T25021211000\\test_diamonds_feature__engine.pkl', type=str, required=False) #for predict
    parser.add_argument('--port', default='9159', type=str, required=False)
    parser.add_argument('--api', default='/inference/', type=str, required=False)
    args   = parser.parse_args()
    return args

def inference_task(  port,load_file='',host='0.0.0.0' ):
    from aiutils.utils import set_logging
    set_logging(log_dir='log',file_name='task_dispatch', mode='dev')
    logging.info('begin inference task')

    #ai_agent = joblib.load( args.load_file )
    from flask import Flask, request, jsonify, redirect, url_for, session, send_file
    app = Flask(__name__)
    app.logger.setLevel(logging.INFO)

    api =  args.api
    if not api.startswith('/'):api  = '/' + api
    if not api.endswith('/'):  api  = api + '/'

    @app.route('%s'%( api ), methods=['POST'] ) #   '/predict/'
    def run_inference( ):
        trigger_data =  request.get_json( )
        sample_df    =  pd.read_json( trigger_data['dataSource1726409734017']  ) #pd.read_csv('dataSource1726409657775__df_train_bin.csv').head(3);
        logging.info("sample_df:%s",sample_df )
        result       = predict_( ai_agent,{"dataSource1726409734017":sample_df})
        logging.info('result %s',result)
        return jsonify( {'message': 'Logged out successfully'} ), 200

    logging.info(' run port[%s] ',  port )
    try:
        #app.run(   debug=True, host='0.0.0.0', port=int(args.port ) )
        app.run( debug=True, host=host, port= port )
    except OSError as e:
        logging.info( f"启动 Flask 服务失败: {e}" )
import sys
def main_logic( args ):
    if  args.task in ['train','explore','offline']:
        #json                    = json.loads()
        with open(args.flowdata_file, "r",encoding='utf8') as file:
            flow_data = json.load(file)
        engine                  = WorkflowEngine( flow_data,args.work_path,args.execute_time )
        from aiutils.utils import  set_logging
        set_logging( log_dir=os.path.join(engine.project_dir,engine.execute_time),file_name=engine.projectname+"__run",mode='prod' )  #run.log
        try:
            exe_status_result   = engine.execute(task='train')
        except:
            logging.error("engine execute train task error")
            import traceback
            errorinfo           = traceback.format_exc()
            logging.error('######errorinfo,%s', errorinfo)
            #return {'errorinfo': errorinfo}
            exe_status_result['errorinfo'] = errorinfo

        #exe_result save
        excute_r_f      = 'statusresults.json'
        execute_path    = os.path.join( engine.project_dir ,engine.execute_time, excute_r_f )
        with open( execute_path, "w") as f:# joblib.dump( exe_status_result, execute_path)
            json.dump( exe_status_result, f )

        if 'errorinfo' not in exe_status_result:
            excute_r_f = '%s__engine.pkl' % engine.projectname;
            execute_path = os.path.join(engine.project_dir, engine.execute_time, excute_r_f)
            joblib.dump(engine, execute_path)
            # try:
            #     import msgpack
            #     with open(excute_r_f, "wb") as f:
            #         f.write(msgpack.packb(engine))
            # except:
            #     import traceback
            #     logging.error( traceback.format_exc() )
    elif args.task in [ 'predict','inference','inline' ]:
        if args.stdin==True:
            from aiutils.utils import set_logging
            set_logging(log_dir='log', file_name='task_dispatch', mode='dev')
            logging.info("begin inference task")
            aiagent = joblib.load(args.load_file)
            while True:
                line = sys.stdin.readline()
                if not line:
                    break
                try:
                    request    = json.loads(line.strip())
                    dataSource = request["dataSource"]

                    # 运行推理
                    result = predict_(aiagent,dataSource)

                    # 返回结果
                    print(json.dumps(result))
                    sys.stdout.flush()
                except Exception as e:
                    logging.error(f"Error processing request: {e}")
        else:
            inference_task( port=args.port, load_file=args.load_file,host=args.host)
    else:
        logging.info('unkwon arg.task[%s]',args.task )
    #engine  save


if __name__ == '__main__':
    args  = set_args()
    main_logic( args )


